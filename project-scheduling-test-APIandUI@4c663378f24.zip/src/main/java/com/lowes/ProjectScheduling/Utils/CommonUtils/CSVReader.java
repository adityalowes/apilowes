package com.lowes.ProjectScheduling.Utils.CommonUtils;

import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.*;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class CSVReader {
    public String path;
    public FileInputStream fis = null;
    public FileOutputStream fileOut = null;





    public Map<Integer, Map<String,String>> getCellDataOfLeadFormsFromCSVFile(String path) {
        String line = "";
        String splitBy = ",";
        int count=0;
        Map<Integer, Map<String,String>> map = new HashMap<>();

        try {
            BufferedReader br = new BufferedReader(new FileReader(path));
           int length= br.readLine().split(",").length;
            while ((line = br.readLine()) != null)
            {
                count++;
                String Employee[]=line.split(splitBy);
                HashMap<String,String> temp = new HashMap<>();
                temp.put("Pincode",Employee[0]);
                temp.put("FirstName",Employee[1]);
                temp.put("LastName",Employee[2]);
                temp.put("Address",Employee[3]);
                temp.put("Phone",Employee[4]);
                temp.put("Email",Employee[5]);
                temp.put("Description",Employee[6]);
                temp.put("Date",Employee[7]);
                map.put(count,temp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return map;
    }

    public Map<Integer, Map<String,String>> getCellDataOfLeadFormsKitchenFromCSVFile(String path) {
        String line = "";
        String splitBy = ",";
        int count=0;
        Map<Integer, Map<String,String>> map = new HashMap<>();
        try {
            BufferedReader br = new BufferedReader(new FileReader(path));
            int length= br.readLine().split(",").length;
            while ((line = br.readLine()) != null)
            {
                count++;
                String Employee[]=line.split(splitBy);
                HashMap<String,String> temp = new HashMap<>();
                temp.put("Pincode",Employee[0]);
                temp.put("FirstName",Employee[1]);
                temp.put("LastName",Employee[2]);
                temp.put("Address",Employee[3]);
                temp.put("City",Employee[4]);
                temp.put("state",Employee[5]);
                temp.put("Zipcode",Employee[6]);
                temp.put("Phone",Employee[7]);
                temp.put("Email",Employee[8]);
                temp.put("Timeline",Employee[9]);
                temp.put("Budget",Employee[10]);
                temp.put("Description",Employee[11]);
                temp.put("Date",Employee[12]);
                map.put(count,temp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return map;
    }


    public long getCountOfRecordsInCSVFile(String path) {
        String line = "";
        String splitBy = ",";
        long rowCount= 0;
        try {
           BufferedReader br = new BufferedReader(new FileReader(path));
            rowCount = br.lines().count();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return rowCount;
    }




}
