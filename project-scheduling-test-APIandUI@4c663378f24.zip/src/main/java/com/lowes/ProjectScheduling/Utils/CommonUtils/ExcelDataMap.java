package com.lowes.ProjectScheduling.Utils.CommonUtils;

import java.util.HashMap;
import java.util.Map;

public  class ExcelDataMap {
   // static ExcelReader APITestDatareader = new ExcelReader(CommonUtils.getProperty("API_TESTDATA_PATH").toString());
   // static ExcelReader UITestDatareader = new ExcelReader(CommonUtils.getProperty("UI_TESTDATA_PATH").toString());

/*public static Map<String,String> getValueForCoreAPI(){
    Map<String,String> map = new HashMap<String,String>();

    map.put("grant_type",APITestDatareader.getCellData("Sheet1","data",2));
    map.put("client_id",APITestDatareader.getCellData("Sheet1","data",3));
    map.put("client_secret",APITestDatareader.getCellData("Sheet1","data",4));

    return map;
}*/

   /* public static Map<String,String> getValueForLeadForms(){
        Map<String,String> map = new HashMap<String,String>();

        map.put("A",UITestDatareader.getCellData("Sheet1","data",2));
        map.put("B",UITestDatareader.getCellData("Sheet1","data",3));
        map.put("client_secret",UITestDatareader.getCellData("Sheet1","data",4));

        return map;
    }*/
}
