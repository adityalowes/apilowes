package com.lowes.ProjectScheduling.Utils.CommonUtils;

import org.testng.annotations.DataProvider;

import java.util.Map;

public class DataProvidersLeadFormKitchen {
    static CSVReader UITestDatareader = new CSVReader();
    long getNumOfSets = UITestDatareader.getCountOfRecordsInCSVFile(CommonUtils.getProperty("LEADFORM_KITCHEN_TESTDATA_CSV_PATH").toString());
    Map<Integer, Map<String,String>> testDataMap;



    @DataProvider(name = "data-provider-leadform-kitchen")


    public Object[][] dpMethod() {Object objArr[][] = new Object[(int)(getNumOfSets-1)][13];
        testDataMap = UITestDatareader.getCellDataOfLeadFormsKitchenFromCSVFile(CommonUtils.getProperty("LEADFORM_KITCHEN_TESTDATA_CSV_PATH").toString());
        for (int i = 0; i < getNumOfSets-1; i++) {
            objArr[i][0] = testDataMap.get(i+1).get("Pincode");
            objArr[i][1] = testDataMap.get(i+1).get("FirstName");
            objArr[i][2] = testDataMap.get(i+1).get("LastName");
            objArr[i][3] = testDataMap.get(i+1).get("Address");
            objArr[i][4] = testDataMap.get(i+1).get("City");
            objArr[i][5] = testDataMap.get(i+1).get("state");
            objArr[i][6] = testDataMap.get(i+1).get("Zipcode");
            objArr[i][7] = testDataMap.get(i+1).get("Phone");
            objArr[i][8] = testDataMap.get(i+1).get("Email");
            objArr[i][9] = testDataMap.get(i+1).get("Timeline");
            objArr[i][10] = testDataMap.get(i+1).get("Budget");
            objArr[i][11] = testDataMap.get(i+1).get("Description");
            objArr[i][12] = testDataMap.get(i+1).get("Date");
        }
        return objArr;

    }
}