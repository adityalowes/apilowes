package com.lowes.ProjectScheduling.Utils.CommonUtils;

import org.apache.commons.lang3.RandomStringUtils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Properties;

public class CommonUtils {
    public static String getProperty(String propertyName) {
        Properties prop = new Properties();
        try {
            FileInputStream file = new FileInputStream("./src/main/resources/application.properties");
            prop.load(file);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        String propVal = prop.getProperty(propertyName);
        return propVal;
    }

    public static String randomString(int n) {
        String generatedRandomString = RandomStringUtils.randomAlphabetic(n);
        return generatedRandomString;
    }


    public static String randomNum(int n) {
        String generatedRandomNum = RandomStringUtils.randomNumeric(n);
        return generatedRandomNum;
    }

    public static String getCurrentDate() {
        String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        return date;
    }

    public static String getCurrentDateInSpecifiedFormat(String format) {
        String date = new SimpleDateFormat(format).format(new Date());
        return date;
    }

    public static String getTomorrowsDateInSpecifiedFormat(String format) {

        LocalDate today = LocalDate.now();
        String tomorrowsDate = (today.plusDays(1)).format(DateTimeFormatter.ISO_DATE);
        String tomorrowDateFormatted = (today.plusDays(1)).format(DateTimeFormatter.ofPattern(format));
        return tomorrowDateFormatted;
    }

    public static String getTomorrowsDate(String format) {

        LocalDate today = LocalDate.now();
        String tomorrowsDate = (today.plusDays(1)).format(DateTimeFormatter.ISO_DATE);
        return tomorrowsDate;
    }

    public static String getTimeStamp() {
        String timeStamp = new SimpleDateFormat("HH:mm:ss").format(new Date());
        return timeStamp;

    }

    /*public static String ConvertDateInSpecifiedFormat(String givenDate , String format){
        String date = new SimpleDateFormat(format).format(new Date());
        return date;

        String tomorrowsDate = (today.plusDays(1)).format(DateTimeFormatter.ISO_DATE);
        String tomorrowDateFormatted = (today.plusDays(1)).format(DateTimeFormatter.ofPattern(format));
        String res= givenDate.format(DateTimeFormatter.ofPattern(format));
        return tomorrowDateFormatted;
    }*/
}
