package com.lowes.ProjectScheduling.Utils.UIUtils;

import com.aventstack.extentreports.Status;
import com.lowes.ProjectScheduling.Pages.Base.BaseTest;
import com.lowes.ProjectScheduling.Utils.CommonUtils.Reporting;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static com.lowes.ProjectScheduling.Pages.Base.BaseTest.driver;

public class ElementFetch {

    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));


    public WebElement getWebElement(String identiferType, String identifierValue) {

        WebElement element=null;
        try {
            switch (identiferType) {
                case "XPATH":
                    element = driver.findElement(By.xpath(identifierValue));

                case "ID":
                    element = driver.findElement(By.id(identifierValue));

                case "CSS":
                    element = driver.findElement(By.cssSelector(identifierValue));

                default:
                    element = null;
            }
        }
        catch(Exception e){
            Reporting.report(e.toString()+"Current page URl. "+ driver.getCurrentUrl(), Status.FAIL);
        }
        return element;
    }

    public WebElement getWebElement(String identifierValue) {
        WebElement element = null;
        try {
            element= driver.findElement(By.xpath(identifierValue));
        }
        catch(Exception e){
            Reporting.report(e.toString()+"Current page URl. "+ driver.getCurrentUrl(), Status.FAIL);
        }
        return element;
    }

    public List<WebElement> getWebElements(String identifierValue) {
        List<WebElement> list=null;
        try {
            list= driver.findElements(By.xpath(identifierValue));
        }
        catch(Exception e){
            Reporting.report(e.toString()+"Current page URl. "+ driver.getCurrentUrl(), Status.FAIL);
        }
        return list;
    }


    public List<WebElement> getWebElements(String identiferType, String identifierValue) {
        List<WebElement> list = null;
        try {
            switch (identiferType) {
                case "XPATH":
                    list = driver.findElements(By.xpath(identifierValue));

                case "ID":
                    list = driver.findElements(By.id(identifierValue));

                case "CSS":
                    list = driver.findElements(By.cssSelector(identifierValue));

                default:
                    list= null;
            }
        }
        catch(Exception e){
            Reporting.report(e.toString()+"Current page URl. "+ driver.getCurrentUrl(), Status.FAIL);
        }
        return list;
    }

    public void clickElement(WebElement getWebElement) {
        try {
            wait.until(ExpectedConditions.visibilityOf(getWebElement));
            highlightElement(getWebElement);
            getWebElement.click();
        } catch (Exception e) {
            Reporting.report(e.toString()+"Current page URl. "+ driver.getCurrentUrl(), Status.FAIL);
            Assert.fail("Issue with Click Function", e);
        }
    }
    public void jsClickElement(WebElement getWebElement) {
        try {
            wait.until(ExpectedConditions.visibilityOf(getWebElement));
            highlightElement(getWebElement);
            JavascriptExecutor executor = (JavascriptExecutor)driver;
            executor.executeScript("arguments[0].click();", getWebElement);
        } catch (Exception e) {
            Reporting.report(e.toString()+"Current page URl. "+ driver.getCurrentUrl(), Status.FAIL);
            Assert.fail("Issue with Click Function", e);
        }
    }
    public String getElementText(WebElement getWebElement) {
        String value ="";
        try {
            wait.until(ExpectedConditions.visibilityOf(getWebElement));
            highlightElement(getWebElement);
            value = getWebElement.getText();
        } catch (Exception e) {
            Reporting.report(e.toString()+"Current page URl. "+ driver.getCurrentUrl(), Status.FAIL);
            Assert.fail("Issue with Click Function", e);
        }
        return value;
    }

    public String getAttributeValue(WebElement getWebElement) {
        String value ="";
        try {
            wait.until(ExpectedConditions.visibilityOf(getWebElement));
            highlightElement(getWebElement);
            if(getWebElement.getAttribute("value")!=null)
                value= getWebElement.getAttribute("value");
        } catch (Exception e) {
            Reporting.report(e.toString()+"Current page URl. "+ driver.getCurrentUrl(), Status.FAIL);
            Assert.fail("Issue with Click Function", e);
        }
        return value;
    }
//    public boolean isClickable(WebElement getWebElement)
//    {
//        try
//        {
//            WebDriverWait wait = new WebDriverWait(BaseTest.driver, Duration.ofSeconds(10));
//            wait.until(ExpectedConditions.elementToBeClickable(getWebElement));
//            return true;
//        }
//        catch (Exception e)
//        {
//            return false;
//        }
//    }

    public WebElement waitForElementToBeClickable(WebElement getWebElement) {
        WebElement element = null;
        try {
            highlightElement(getWebElement);
            element =
                    wait.until(ExpectedConditions.elementToBeClickable(getWebElement));
        } catch (Exception e) {
            Reporting.report(e.toString()+"Current page URl. "+ driver.getCurrentUrl(), Status.FAIL);
        }
        return element;
    }

    public WebElement waitForElementToBeVisible(String identifierValue) {
        WebElement element = null;
        try {
            element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(identifierValue)));
        } catch (Exception e) {
            Reporting.report(e.toString()+"Current page URl. "+ driver.getCurrentUrl(), Status.FAIL);
        }
        return element;
    }

    public void scrollUntilElementIsClickable(WebElement getWebElement) {
        try {
            ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);",getWebElement);
            // wait.until(ExpectedConditions.visibilityOf(getWebElement));
            JavascriptExecutor js = (JavascriptExecutor) driver;
            highlightElement(getWebElement);
            js.executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", getWebElement);
        }
        catch (Exception e) {
            Reporting.report(e.toString()+"Current page URl. "+ driver.getCurrentUrl(), Status.FAIL);
        }
    }

    public void scrollUntilElementIsVisible(WebElement getWebElement) {
        try {
            ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(false);",getWebElement);
            // wait.until(ExpectedConditions.visibilityOf(getWebElement));
            JavascriptExecutor js = (JavascriptExecutor) driver;
            highlightElement(getWebElement);
            js.executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", getWebElement);
        }
        catch (Exception e) {
            Reporting.report(e.toString()+"Current page URl. "+ driver.getCurrentUrl(), Status.FAIL);
        }
    }

    public void scrollByCordinates(String cordinate1,String cordinate2) {
        try {

            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("window.scrollBy("+cordinate1+","+cordinate2+")");
        }
        catch (Exception e) {
            Reporting.report(e.toString()+"Current page URl. "+ driver.getCurrentUrl(), Status.FAIL);
        }
    }


    public void scrollTillBottomOfPage() {
        try {

            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("window.scrollBy(0,document.body.scrollHeight)", "");
            // js.executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", getWebElement);
        }
        catch (Exception e) {
            Reporting.report(e.toString()+"Current page URl. "+ driver.getCurrentUrl(), Status.FAIL);
        }
    }

    public void setTextElement(WebElement getWebElement, String value) {
        try {
            wait.until(ExpectedConditions.visibilityOf(getWebElement));
            highlightElement(getWebElement);
            getWebElement.clear();
            getWebElement.sendKeys(value);
        } catch (Exception e) {
            Reporting.report(e.toString()+"Current page URl. "+ driver.getCurrentUrl(), Status.FAIL);
            Assert.fail("Issue with SetTextElement", e);
        }

    }

    public void highlightElement(WebElement getWebElement) {
        try {
            for (int i = 0; i < 2; i++) {
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("arguments[0].setAttribute('style', arguments[1]);", getWebElement, "color: yellow; border: 15px solid red;");
                js.executeScript("arguments[0].setAttribute('style', arguments[1]);", getWebElement, "");
            }
        }
        catch (Exception e) {
            Reporting.report(e.toString()+"Current page URl. "+ driver.getCurrentUrl(), Status.FAIL);
        }

    }

    public void selectDropDownByText(WebElement getWebElement, String dropDownVisibleText) {
        try {
//            wait.until(ExpectedConditions.visibilityOf(getWebElement));
            Select dropdown = new Select(getWebElement);
            dropdown.selectByVisibleText(dropDownVisibleText);
        } catch (Exception e) {
            Reporting.report(e.toString()+"Current page URl. "+ driver.getCurrentUrl(), Status.FAIL);
            Assert.fail("Issue with selectDropDownByText:", e);
        }
    }



    public void selectDropDownByIndex(WebElement getWebElement, int index) {
        try {
//            wait.until(ExpectedConditions.visibilityOf(getWebElement));
            Select dropdown = new Select(getWebElement);
            dropdown.selectByIndex(index);
        } catch (Exception e) {
            Reporting.report(e.toString()+"Current page URl. "+ driver.getCurrentUrl(), Status.FAIL);
            Assert.fail("Issue with selectDropDownByIndex:", e);
        }
    }



    public boolean validatePicklistValues(String fieldName, String[] expectedPicklistValue) throws IOException {
        boolean result1;
        boolean result2 = false;
        boolean result;

        ArrayList<String> expectedDropDownItems = new ArrayList<String>();
        for (int i = 0; i < expectedPicklistValue.length; i++)
            expectedDropDownItems.add(expectedPicklistValue[i]);

        waitForElementToBeVisible("//select[@data-testid='" + fieldName + "']/..");
        JavascriptExecutor js = (JavascriptExecutor) driver;
//        js.executeScript("arguments[0].click();",BaseTest.driver.findElement(By.xpath("//select[@data-testid='"+fieldName+"']/..")));
        driver.findElement(By.xpath("//select[@data-testid='" + fieldName + "']/..")).click();
        List<WebElement> valuesUnderTypeDropDown = driver.findElements(By.xpath("//select[@data-testid='" + fieldName + "']/option"));
//        js.executeScript("arguments[0].click();",BaseTest.driver.findElement(By.xpath("//select[@data-testid='"+fieldName+"']/option")));
        driver.findElement(By.xpath("//select[@data-testid='" + fieldName + "']/option")).click();
        List<String> actualDropDownItems = new ArrayList<String>();
        for (WebElement value : valuesUnderTypeDropDown)
            actualDropDownItems.add(value.getAttribute("innerText").toString());

        System.out.println(fieldName + "expectedDropDownItems: " + expectedDropDownItems);
        System.out.println(fieldName + "actualDropDownItems: " + actualDropDownItems);
        int actsize = actualDropDownItems.size() - 1;

        //verify both the lists having same size
        if (actualDropDownItems.size() != expectedDropDownItems.size()) {
            System.out.println("number of Picklist values in " + fieldName + " Drop Down are not correct !! Expected size: " + expectedDropDownItems.size() +
                    "!! Actual size of picklist value is: " + actsize);
            BaseTest.logger.warning("Number of Picklist values in " + fieldName + " Drop Down are not correct !! Expected size: " + expectedDropDownItems.size() +
                    "!! Actual size of picklist value is: " + actsize);
            result1 = false;
        } else {
            result1 = true;
        }
        int count = 0;
        //Compare expected and actual list
        int minSize = Math.min(expectedDropDownItems.size(), actualDropDownItems.size() - 1);

        for (int i = 0; i < minSize; i++) {
            if (!expectedDropDownItems.get(i).equals(actualDropDownItems.get(i))) {
                count++;
                System.out.println("Drop-down values are NOT in correct order !! Expected Value: " + expectedDropDownItems.get(i) +
                        "!! Actual Value: " + actualDropDownItems.get(i));
            }
        }
        if (count > 0)
            result2 = false;
        else
            result2 = true;
        if (result1 == true && result2 == true) {
            BaseTest.logger.pass(fieldName + " picklist values validated successfully");
            BaseTest.logger.pass(fieldName + " actual DropDown Items: " + actualDropDownItems);
            BaseTest.captureScreenshot("Dropdown List validation");
            result = true;
        } else {
            BaseTest.logger.warning(fieldName + " expected DropDown Items: " + expectedDropDownItems);
            BaseTest.logger.warning(fieldName + " actual DropDown Items: " + actualDropDownItems);
            result = false;
        }
        return result;
    }

    public void selectRandomElement(String identifierValue) {
        try {
            getWebElements(identifierValue);
            int maxSize = getWebElements(identifierValue).size();
            Random random = new Random();
            int randomElement = random.nextInt(maxSize);
            clickElement(getWebElements(identifierValue).get(randomElement));
        }
        catch(Exception e){
            Reporting.report(e.toString()+"Current page URl. "+ driver.getCurrentUrl(), Status.FAIL);
        }
    }

    public String selectAndReturnRandomElement(String identifierValue) {
        String text = " ";
        try {
            getWebElements(identifierValue);
            int maxSize = getWebElements(identifierValue).size();
            Random random = new Random();
            int randomElement = random.nextInt(maxSize);
            text = getWebElements(identifierValue).get(randomElement).getAttribute("aria-label");
                    clickElement(getWebElements(identifierValue).get(randomElement));
        }
        catch(Exception e){
            Reporting.report(e.toString()+"Current page URl. "+ driver.getCurrentUrl(), Status.FAIL);
        }
        return text;
    }

}
