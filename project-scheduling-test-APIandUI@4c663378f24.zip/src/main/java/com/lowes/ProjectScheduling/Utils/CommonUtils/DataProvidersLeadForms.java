package com.lowes.ProjectScheduling.Utils.CommonUtils;

import org.testng.annotations.DataProvider;

import java.util.Map;

public class DataProvidersLeadForms {
    static CSVReader UITestDatareader = new CSVReader();
    long getNumOfSets = UITestDatareader.getCountOfRecordsInCSVFile(CommonUtils.getProperty("LEADFORM_TESTDATA_CSV_PATH").toString());
    Map<Integer, Map<String,String>> testDataMap;



    @DataProvider(name = "data-provider-leadforms")


    public Object[][] dpMethod() {Object objArr[][] = new Object[(int)(getNumOfSets-1)][8];
        testDataMap = UITestDatareader.getCellDataOfLeadFormsFromCSVFile(CommonUtils.getProperty("LEADFORM_TESTDATA_CSV_PATH").toString());
        for (int i = 0; i < getNumOfSets-1; i++) {
            objArr[i][0] = testDataMap.get(i+1).get("Pincode");
            objArr[i][1] = testDataMap.get(i+1).get("FirstName");
            objArr[i][2] = testDataMap.get(i+1).get("LastName");
            objArr[i][3] = testDataMap.get(i+1).get("Address");
            objArr[i][4] = testDataMap.get(i+1).get("Phone");
            objArr[i][5] = testDataMap.get(i+1).get("Email");
            objArr[i][6] = testDataMap.get(i+1).get("Description");
            objArr[i][7] = testDataMap.get(i+1).get("Date");
        }
        return objArr;

    }
}
