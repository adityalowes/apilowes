package com.lowes.ProjectScheduling.Utils.CommonUtils;

import org.apache.commons.codec.binary.Base64;

public  class EncodeStrings {


    public String encodeGrantType(){
        String str="client_credentials";

        // Encode data on your side using BASE64
        byte[] encodedString = Base64.encodeBase64(str.getBytes());
        System.out.println("encoded value is " + new String(encodedString));

        return new String(encodedString);
    }

    public String encodeClientId(){
        String str="";

        // Encode data on your side using BASE64
        byte[] encodedString = Base64.encodeBase64(str.getBytes());
        System.out.println("encoded value is " + new String(encodedString));

        return new String(encodedString);
    }

    public String encodeClientSecret(){
        String str="";

        // Encode data on your side using BASE64
        byte[] encodedString = Base64.encodeBase64(str.getBytes());
        System.out.println("encoded value is " + new String(encodedString));

        return new String(encodedString);
    }

}
