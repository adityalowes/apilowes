package com.lowes.ProjectScheduling.Utils.UIUtils;

import com.lowes.ProjectScheduling.Pages.Base.BaseTest;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;


public class ActionsClass {

    BaseTest bt = new BaseTest();

    public void actionSendKeys(WebElement getWebElement, String key, String text)
    {
        Actions actions = new Actions(bt.driver);

        switch (key.toLowerCase()) {
            case "enter":
                actions.sendKeys(Keys.ENTER).build().perform();
                break;
            case "escape":
                actions.sendKeys(Keys.ESCAPE).build().perform();
                break;
            case "tab":
                actions.sendKeys(Keys.TAB).build().perform();
                break;
            case "space":
                actions.sendKeys(Keys.SPACE).build().perform();
                break;

            default:
                System.out.println("Unsupported Key:" + key);
        }
    }
}
