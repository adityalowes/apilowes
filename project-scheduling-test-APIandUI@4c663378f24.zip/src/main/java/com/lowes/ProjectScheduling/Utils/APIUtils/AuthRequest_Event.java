package com.lowes.ProjectScheduling.Utils.APIUtils;

import com.lowes.ProjectScheduling.Utils.CommonUtils.CommonUtils;
import com.lowes.ProjectScheduling.Utils.CommonUtils.EncodeStrings;
import io.restassured.path.json.JsonPath;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;

public class AuthRequest_Event {
    EncodeStrings obj = new  EncodeStrings();
    public String token = "";

    @Test
    public String validate_Auth_Request_Event() {

        //  ExcelDataMap.getValueForCoreAPI();
        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("AUTH_URL_EVENT")).
                queryParam("grant_type", "client_credentials").
                queryParam("client_id", "29f518fac35f71698e070d0d1895feb6").
                queryParam("client_secret", "e7dc29fd2811816e35d2458713b49d19").
                when().
                post(CommonUtils.getProperty("AUTH_URL_EVENT")).then().log().all().extract().response().asString();
        JsonPath jsl = new JsonPath(extractHeader);
        token = jsl.getString("access_token");
        return token;

    }
}
