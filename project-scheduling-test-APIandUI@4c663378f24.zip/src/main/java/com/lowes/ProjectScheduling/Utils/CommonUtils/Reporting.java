package com.lowes.ProjectScheduling.Utils.CommonUtils;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

import com.lowes.ProjectScheduling.Pages.Base.BaseTest;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.io.FileHandler;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;


public class Reporting extends BaseTest {

    public static String dateStamp = CommonUtils.getCurrentDate();
    public static String timeStamp = CommonUtils.getTimeStamp();
    public static String reportPath = null;


    public static void createTest(String test_name) {

        logger = extent.createTest(test_name);
    }

    public static void systeminfo() {

        extent.setSystemInfo("OS", "WIN10");
    }

    public static void before() {

        logger.info(MarkupHelper.createLabel("Test Automation Report for Radiant Team", ExtentColor.LIME));
    }

    public static void report(String info, Status status) {

        try {
            switch (status) {

                case PASS:
                    logger.pass(info, MediaEntityBuilder.createScreenCaptureFromBase64String(getBase()).build());
                    break;

                case FAIL:
                    logger.fail(info, MediaEntityBuilder.createScreenCaptureFromBase64String(getBase()).build());
                    break;

                case INFO:
                    logger.info(info, MediaEntityBuilder.createScreenCaptureFromBase64String(getBase()).build());
                    break;

                case SKIP:
                    logger.skip(info, MediaEntityBuilder.createScreenCaptureFromBase64String(getBase()).build());
                    break;
                default:
                    logger.log(status.WARNING, "Please Provide Correct Status");
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }


    public static String getScreenshot(WebDriver driver) throws Exception {
        TakesScreenshot scrShot = ((TakesScreenshot) driver);
        File SrcFile =
                scrShot.getScreenshotAs(OutputType.FILE);
        String destination =
                System.getProperty("user.dir") + "/Screenshots/" + CommonUtils.getTimeStamp().replaceAll(":", "_") + ".png";
        System.out.println("Destination" + destination);
        File DestFile = new
                File(destination);
        FileHandler.copy(SrcFile, DestFile);
        return destination;

    }


    public static String getBase() {

        return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);
    }

    public static void flushReport() {

        extent.flush();
        File htmlFile = new File(reportPath);

        try {
            Desktop.getDesktop().browse(htmlFile.toURI());
        } catch (IOException e) {
            System.out.println("File not Found");
            e.printStackTrace();
        }

    }
}

