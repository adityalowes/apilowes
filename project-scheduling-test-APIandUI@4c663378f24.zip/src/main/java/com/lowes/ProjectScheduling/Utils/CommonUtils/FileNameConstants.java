package com.lowes.ProjectScheduling.Utils.CommonUtils;

public class FileNameConstants {


    public static final String HEADER_AUTHORIZATION="Authorization";
    public static final String HEADER_CONTENTTYPE="Content-Type";
    public static final String HEADER_APPLICATIONJSON="application/json";
    public static final String HEADER_APPLICATIONJSON_CHARSET="application/json; charset=utf-8";
    public static final String HEADER_BEARER="Bearer ";
    public static final String HEADER_DISPLAYTYPE = "Display-Type";
    public static final String HEADER_DISPLAYTYPE_FORM = "form";
    public static final String HEADER_DISPLAYTYPE_SCHEDULEFORM = "schedule_form";
    public static final String HEADER_DISPLAYTYPE_SCHEDULE = "schedule";
    public static final String HEADER_ROUTINGTYPE = "Routing-Type";
    public static final String HEADER_ROUTINGTYPE_DYNAMICS = "Dynamics";
    public static final String HEADER_ROUTINGTYPE_IME = "IME";
    public static final String HEADER_API_VERSION = "x-api-version";

}
