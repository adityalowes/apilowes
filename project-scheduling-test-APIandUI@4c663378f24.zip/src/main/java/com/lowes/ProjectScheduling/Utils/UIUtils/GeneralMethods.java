package com.lowes.ProjectScheduling.Utils.UIUtils;


import org.apache.commons.lang3.RandomStringUtils;

public class GeneralMethods {


    public String randomString(int n)
    {
        String generatedRandomString = RandomStringUtils.randomAlphabetic(n);
        return generatedRandomString;
    }


    public String randomNum(int n)
    {
        String generatedRandomNum = RandomStringUtils.randomNumeric(n);
        return generatedRandomNum;
    }


}
