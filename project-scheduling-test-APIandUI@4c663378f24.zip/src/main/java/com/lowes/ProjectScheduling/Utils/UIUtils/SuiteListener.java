package com.lowes.ProjectScheduling.Utils.UIUtils;

import com.lowes.ProjectScheduling.Pages.Base.BaseTest;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.IAnnotationTransformer;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class SuiteListener implements ITestListener, IAnnotationTransformer {

    LocalDateTime currentTime = LocalDateTime.now();
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
    String timestamp = currentTime.format(formatter);


        public void onTestFailure (ITestResult result)
        {

            String filename = System.getProperty("user.dir")+ File.separator + "reports"+File.separator+"screenshots"+File.separator+result.getMethod().getMethodName();
//            String filename=System.getProperty("user.dir") + File.separator + "reports" + File.separator + "screenshots" + File.separator + "LowesAutomation_" + timestamp;
            File file = ((TakesScreenshot)BaseTest.driver).getScreenshotAs(OutputType.FILE);

            try {
                FileUtils.copyFile(file, new File(filename + ".png"));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    public void onTestSuccess (ITestResult result)
    {

        String filename = System.getProperty("user.dir")+ File.separator + "reports"+File.separator+"screenshots"+File.separator+result.getMethod().getMethodName();
//            String filename=System.getProperty("user.dir") + File.separator + "reports" + File.separator + "screenshots" + File.separator + "LowesAutomation_" + timestamp;
        File file = ((TakesScreenshot) BaseTest.driver).getScreenshotAs(OutputType.FILE);

        try {
            FileUtils.copyFile(file, new File(filename + ".png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

//        public void transform (ITestAnnotation annotation, Class testClass, Constructor testConstructor, Method
//        testMethod)
//        {
//            annotation.setRetryAnalyzer(RetryAnalayzer.class);
//        }


}