package com.lowes.ProjectScheduling.Pages.PageActions.LeadForms;

import com.aventstack.extentreports.Status;
import com.lowes.ProjectScheduling.Pages.PageObjects.LeadForms.LeadFormsConfirmationPageElements;
import com.lowes.ProjectScheduling.Utils.CommonUtils.CommonUtils;
import com.lowes.ProjectScheduling.Utils.CommonUtils.Reporting;
import com.lowes.ProjectScheduling.Utils.UIUtils.ElementFetch;
import org.testng.asserts.SoftAssert;

import static com.lowes.ProjectScheduling.Pages.Base.BaseTest.driver;
import static com.lowes.ProjectScheduling.Pages.PageActions.LeadForms.LeadFormsScheduleConfirmationPage.*;


public class LeadFormsConsultationConfirmationPage {

    SoftAssert softAssert = new SoftAssert();
    ElementFetch ele = new ElementFetch();


    public void VerifyConfirmationPage(String firstName,String lastName,String timeFromExcel) {
        try {
            ele.scrollUntilElementIsClickable(ele.getWebElement(LeadFormsConfirmationPageElements.ConfirmationHeader));
            String successMessageHeader = ele.getElementText(ele.getWebElement(LeadFormsConfirmationPageElements.ConfirmationHeader));
            if(driver.getCurrentUrl().contains("counter"))
            softAssert.assertEquals(successMessageHeader,"Your virtual consultation is confirmed.");
            else
                softAssert.assertEquals(successMessageHeader,"Your consultation is confirmed.");
            Reporting.report("Success Message fetched from UI "+successMessageHeader,Status.INFO);
            String successMessageSubHeader = ele.getElementText(ele.getWebElement(LeadFormsConfirmationPageElements.ConfirmationSubHeader));
            softAssert.assertNotNull(successMessageSubHeader,"Success sub header message is not displayed");
            Reporting.report("Success Message sub header details fetched from UI "+successMessageSubHeader,Status.INFO);
            if(!(driver.getCurrentUrl().contains("counter"))) {
                 String EmailIntimationText = ele.getElementText(ele.getWebElement(LeadFormsConfirmationPageElements.emailText));
                softAssert.assertEquals(EmailIntimationText.replaceAll("\n",""),"You'll receive an email with a specific time frame and the name of your consultant a few days before your appointment. If you need to cancel or reschedule, you canmanage your appointment hereor from the email we're sending.");
                 Reporting.report("Email intimation text details fetched from//input[@aria-label='FirstName'] UI "+EmailIntimationText,Status.INFO);
                  String ConsultationDetailsHeader = ele.getElementText(ele.getWebElement(LeadFormsConfirmationPageElements.beforeConsultationHeader));
                  softAssert.assertEquals(ConsultationDetailsHeader,"Before Your Consultation");
                 Reporting.report("Consultation Details header text fetched from UI "+ConsultationDetailsHeader,Status.INFO);
            }
            String name = ele.getElementText(ele.getWebElement(LeadFormsConfirmationPageElements.NameValue));
            softAssert.assertEquals(name,firstName+" "+lastName);
            Reporting.report("Name fetched from UI "+name,Status.INFO);
            ele.scrollUntilElementIsVisible(ele.getWebElement(LeadFormsConfirmationPageElements.dateValue));

            String date = ele.getElementText(ele.getWebElement(LeadFormsConfirmationPageElements.dateValue));

            softAssert.assertNotNull(date,"Date value not fetched from UI");
            if(timeFromExcel.equalsIgnoreCase("Random")) {
                softAssert.assertEquals(date, formattedDateUI);
            }
            if(timeFromExcel.equalsIgnoreCase("today")) {
                softAssert.assertEquals(date, CommonUtils.getCurrentDateInSpecifiedFormat("MMM d, YYYY"));
            }
            if(timeFromExcel.equalsIgnoreCase("tomorrow")) {
                softAssert.assertEquals(date, CommonUtils.getTomorrowsDateInSpecifiedFormat("MMM d, YYYY"));
            }
            Reporting.report("Date fetched from UI "+date,Status.INFO);
            ele.scrollUntilElementIsVisible(ele.getWebElement(LeadFormsConfirmationPageElements.timeValue));
            String time = ele.getElementText(ele.getWebElement(LeadFormsConfirmationPageElements.timeValue));
            softAssert.assertNotNull(time,"Time value not fetched from UI");
            if(!(driver.getCurrentUrl().contains("counter")))
            softAssert.assertEquals(time,timeUI.substring(timeUI.indexOf(":")+2),"Time value in schedule confirmation and confirm confirmation screen is not matching");
            Reporting.report("Time fetched from UI "+time,Status.INFO);
            ele.scrollUntilElementIsVisible(ele.getWebElement(LeadFormsConfirmationPageElements.address));
            String Address = ele.getElementText(ele.getWebElement(LeadFormsConfirmationPageElements.address));
            softAssert.assertNotNull(Address,"Address value not fetched from UI");
            softAssert.assertEquals(Address,AddressUI,"Address value in schedule confirmation and confirm consultation screen not matching");
            Reporting.report("Address fetched from UI "+Address,Status.INFO);
            if(!(driver.getCurrentUrl().contains("counter"))) {
                String beforeConsultationHeader = ele.getElementText(ele.getWebElement(LeadFormsConfirmationPageElements.beforeConsultationHeader));
                softAssert.assertEquals(beforeConsultationHeader, "Before Your Consultation");
                Reporting.report("Before Consultation Header  fetched from UI " + beforeConsultationHeader, Status.INFO);
                String adultImageText = ele.getElementText(ele.getWebElement(LeadFormsConfirmationPageElements.adultImageText));
                softAssert.assertEquals(adultImageText, "An adult age 18 or older must be present.");
                Reporting.report("Before Consultation Image 1 text  fetched from UI ", Status.INFO);
                String petsImageText = ele.getElementText(ele.getWebElement(LeadFormsConfirmationPageElements.PetsImageText));
                softAssert.assertEquals(petsImageText, "Put your pets in a safe place.");
                Reporting.report("Before Consultation Image 2 text  fetched from UI ", Status.INFO);
                String spaceImageText = ele.getElementText(ele.getWebElement(LeadFormsConfirmationPageElements.SpaceImageText));
                softAssert.assertEquals(spaceImageText.replaceAll("\n", ""), "Make sure you have a quiet, cleared space todiscuss your project.");
                Reporting.report("Before Consultation Image 3 text  fetched from UI", Status.INFO);
                String Image1 = ele.getElementText(ele.getWebElement(LeadFormsConfirmationPageElements.adultImage));
                softAssert.assertNotNull(Image1, "First image not visible in 'Before Your Consultation' section");
                Reporting.report("First Image visibility verified from UI ", Status.INFO);
                String Image2 = ele.getElementText(ele.getWebElement(LeadFormsConfirmationPageElements.PetsImage));
                softAssert.assertNotNull(Image2, "Second image not visible in 'Before Your Consultation' section");
                Reporting.report("Second Image visibility verified from UI ", Status.INFO);
                String Image3 = ele.getElementText(ele.getWebElement(LeadFormsConfirmationPageElements.SpaceImage));
                softAssert.assertNotNull(Image3, "Third image not visible in 'Before Your Consultation' section");
                Reporting.report("Third Image visibility verified from UI ", Status.INFO);
            }
            Reporting.report("Consultation Confirmed and verified successfully", Status.PASS);
        }
        catch (Exception e){
            Reporting.report("Could not verify details of consultation confirmation screen successfully",Status.FAIL);
        }
        softAssert.assertAll();
    }



}

