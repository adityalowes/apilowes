package com.lowes.ProjectScheduling.Pages.PageObjects.LeadForms;

public interface LeadFormsScheduleConsultationElements {

    String getStartedHeader = "//*[contains(text(),'Get Started')]";
    String scheduleConsultaionHeader="//*[@alt='Schedule Consultation']/parent::h3//span";
    String requestConsultaionHeader="//*[text()='Request FREE Virtual ']/parent::h3//span";
    String NameValue ="//p[text()='Name']/parent::div//p[2]";
    String AddressValue = "//p[text()='Installation Address']/parent::div//p[2]";
    String PhoneNumValue = "//p[text()='Phone']/parent::div//p[2]";
    String emailAddressValue = "//p[text()='Email Address']/parent::div//p[2]";
    String projectDescriptionValue = "//p[text()='Project Description']/parent::div//p[2]";
    String ChooseADayHeader="//*[text()='Choose a Day']";
    String ChooseADayHeaderKitchen="//*[text()='Select a Date.']";
   String DatePicker = "//div[@class='select--container']/span/label[text()='Date']";
    String DatePickerKitchen ="//select[contains(@class,'select--input completed completed')]";
   String DateValue = "//div[@class='select--container']/span/span";
    String DateValueNew = "//select[@class='select--input completed completed']";
    String AvailableDates ="//div[@class='calendar-body']//div//button[not(contains(@class,'disabled'))]";

    String TodaysDate ="//div[@class='calendar-body']//div//button[(contains(@class,'--circle day selected today'))]";

    String TodaysDateNew = "//button[@color='interactive' and contains(@class,'selected')]";
    String TomorrowsDate ="//div[@class='calendar-body']//div//button[not(contains(@class,'disabled')) and not(contains(@class,'today'))]";
    String ChosseTimeHaeder="//*[text()='Choose a consultation window.']";
    String ChosseTimeHaederKitchen="//*[text()='Select a Time.']";
    String TimePicker ="//div[@class='select--container']/span/label[text()='Time']";
    String TimePickerNew ="//select[@aria-label='timeSelect' or @name='time']";
    String TimeDropdownList ="//div[@class='timepicker-popover shape--rounded']//li//button[not(contains(@class,'disabled'))]";
    String TimeDropdownListNew ="//select[@aria-label='timeSelect']/option";

    String TimeValue="//div[@class='select--container']/span/label[text()='Time']/parent::span/span";
    String BackBtn="//button[@aria-label='Back']";
    String ConfirmConsulatationBtn = "//button[@aria-label='ConfirmConsultation']";

    String ConfirmationHeader = "//div[@class='alert-title']";
    String ConfirmationSubHeader ="//div[@class='alert-subtitle']";


}
