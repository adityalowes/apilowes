package com.lowes.ProjectScheduling.Pages.PageActions.LeadForms;

import com.aventstack.extentreports.Status;
import com.lowes.ProjectScheduling.Pages.PageObjects.LeadForms.LeadFormsLandingPageElements;
import com.lowes.ProjectScheduling.Pages.PageObjects.LeadForms.LeadFormsScheduleConsultationElements;
import com.lowes.ProjectScheduling.Utils.CommonUtils.CommonUtils;
import com.lowes.ProjectScheduling.Utils.CommonUtils.Reporting;
import com.lowes.ProjectScheduling.Utils.UIUtils.ElementFetch;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import static com.lowes.ProjectScheduling.Pages.Base.BaseTest.driver;

public class LeadFormsContactInformationPage {

    SoftAssert softAssert = new SoftAssert();
    ElementFetch ele = new ElementFetch();
    static String addressUI;
    static String zipcode;
    static String city;

    public void VerifyLandingPage(String pincode,String category) {
        try {
            driver.get(CommonUtils.getProperty("stageURL")+category);
            if (driver.getCurrentUrl().contains("countertops"))
                ele.scrollByCordinates("50", "1000");
            else
                ele.scrollByCordinates("50", "2000");
            ele.scrollUntilElementIsClickable(ele.getWebElement(LeadFormsLandingPageElements.searchZipCode));
            Reporting.report("Successfully scrolled till zipcode field", Status.INFO);
            ele.setTextElement(ele.getWebElement(LeadFormsLandingPageElements.searchZipCode), pincode);
            Reporting.report("Successfully entered zipcode value", Status.INFO);
            ele.clickElement(ele.getWebElement(LeadFormsLandingPageElements.arrowBtb));
            Reporting.report("Successfully clicked on arrow button", Status.INFO);
            ele.clickElement(ele.getWebElement(LeadFormsLandingPageElements.setAsMyStoreBtn));
            Reporting.report("Successfully clicked on 'Set as my Store' button", Status.INFO);
            if (driver.getCurrentUrl().contains("countertops")) {
                ele.scrollUntilElementIsClickable(ele.getWebElement(LeadFormsLandingPageElements.getstarttedHeader));
                Assert.assertEquals(ele.getElementText(ele.getWebElement(LeadFormsLandingPageElements.getstarttedHeader)), "Get Started With Your Project");

            }
            else {
                ele.scrollUntilElementIsClickable(ele.getWebElement(LeadFormsLandingPageElements.getstarttedHeader));
                Assert.assertEquals(ele.getElementText(ele.getWebElement(LeadFormsLandingPageElements.getstarttedHeader)), "Get Started With Your Installation");

            }
            Reporting.report("Lead form opened successfully", Status.PASS);
        } catch (Exception e) {
            Reporting.report("Could not successfully open lead form after entering zipcode", Status.FAIL);
        }
    }

    public void verifyLandingPageErrorMsg() {
        try {
            ele.scrollUntilElementIsClickable(ele.getWebElement(LeadFormsLandingPageElements.NextBtn));
            ele.clickElement(ele.getWebElement(LeadFormsLandingPageElements.NextBtn));
            Reporting.report("Successfully clicked on 'Next' button", Status.INFO);
            ele.setTextElement(ele.getWebElement(LeadFormsLandingPageElements.firstname), "Pooj");
            Reporting.report("Successfully entered first name value", Status.INFO);
            ele.setTextElement(ele.getWebElement(LeadFormsLandingPageElements.lastname), "Shaw");
            Reporting.report("Successfully entered last name value", Status.INFO);
            ele.setTextElement(ele.getWebElement(LeadFormsLandingPageElements.installationAdress), "123 Test");
            Reporting.report("Successfully entered installation street address value", Status.INFO);
            ele.waitForElementToBeClickable(ele.getWebElement(LeadFormsLandingPageElements.AddressList));
            ele.selectRandomElement(LeadFormsLandingPageElements.AddressList);
            ele.setTextElement(ele.getWebElement(LeadFormsLandingPageElements.phoneNum), "7043025527");
            Reporting.report("Successfully entered phone number value", Status.INFO);
            ele.setTextElement(ele.getWebElement(LeadFormsLandingPageElements.email), "test@test.com");
            Reporting.report("Successfully entered email value", Status.INFO);
            ele.setTextElement(ele.getWebElement(LeadFormsLandingPageElements.descriptionText), "test");
            Reporting.report("Successfully entered description text value", Status.INFO);


        } catch (Exception e) {
            Reporting.report("Could not successfully open lead form after entering zipcode", Status.FAIL);
        }
    }

    public void VerifyContactInformationPage(String firstName, String lastName, String address, String phoneNo, String email, String description) {
        try {
            ele.scrollUntilElementIsClickable(ele.getWebElement(LeadFormsLandingPageElements.firstname));
            Reporting.report("Successfully scrolled till first name field", Status.INFO);
            ele.setTextElement(ele.getWebElement(LeadFormsLandingPageElements.firstname), firstName);
            Reporting.report("Successfully entered first name value", Status.INFO);
            ele.setTextElement(ele.getWebElement(LeadFormsLandingPageElements.lastname), lastName);
            Reporting.report("Successfully entered last name value", Status.INFO);
            ele.setTextElement(ele.getWebElement(LeadFormsLandingPageElements.installationAdress), address);
            Reporting.report("Successfully entered installation street address value", Status.INFO);
            ele.waitForElementToBeClickable(ele.getWebElement(LeadFormsLandingPageElements.AddressList));
            ele.selectRandomElement(LeadFormsLandingPageElements.AddressList);
            addressUI = ele.getAttributeValue(ele.getWebElement(LeadFormsLandingPageElements.installationAdress));
            System.out.println("*********************"+addressUI);
            zipcode = ele.getElementText(ele.getWebElement(LeadFormsLandingPageElements.zipcode));
            city = ele.getElementText(ele.getWebElement(LeadFormsLandingPageElements.city));
            ele.setTextElement(ele.getWebElement(LeadFormsLandingPageElements.phoneNum), phoneNo);
            Reporting.report("Successfully entered phone number value", Status.INFO);
            ele.setTextElement(ele.getWebElement(LeadFormsLandingPageElements.email), email);
            Reporting.report("Successfully entered email value", Status.INFO);
            ele.setTextElement(ele.getWebElement(LeadFormsLandingPageElements.descriptionText), description);
            Reporting.report("Successfully entered description text value", Status.INFO);
            ele.clickElement(ele.getWebElement(LeadFormsLandingPageElements.NextBtn));
            Reporting.report("Successfully clicked on 'Next' button", Status.INFO);
            ele.waitForElementToBeVisible((LeadFormsScheduleConsultationElements.scheduleConsultaionHeader));
            Assert.assertEquals(ele.getElementText(ele.getWebElement(LeadFormsScheduleConsultationElements.scheduleConsultaionHeader)), "Schedule Consultation");
            Reporting.report("Information supplied successfully in Contact information page", Status.PASS);
        } catch (Exception e) {
            Reporting.report("Could not successfully open lead form after entering zipcode", Status.FAIL);
        }

    }

    public void VerifyNewLeadFormContactInformationPage(String firstName, String lastName, String address, String City, String state, String Zipcode, String phoneNo, String email, String timeline, String budget, String description) {
        try {
            ele.scrollUntilElementIsClickable(ele.getWebElement(LeadFormsLandingPageElements.firstname));
            Reporting.report("Successfully scrolled till first name field", Status.INFO);
            ele.setTextElement(ele.getWebElement(LeadFormsLandingPageElements.firstname), firstName);
            Reporting.report("Successfully entered first name value", Status.INFO);
            ele.setTextElement(ele.getWebElement(LeadFormsLandingPageElements.lastname), lastName);
            Reporting.report("Successfully entered last name value", Status.INFO);
            ele.setTextElement(ele.getWebElement(LeadFormsLandingPageElements.installationAdress), address);
            Reporting.report("Successfully entered installation street address value", Status.INFO);
            ele.clickElement(ele.getWebElement(LeadFormsLandingPageElements.ManualAddress));

            //ele.waitForElementToBeClickable(ele.getWebElement(FencingLeadFormsLanndingPageElements.AddressList));
            //ele.selectRandomElement(FencingLeadFormsLanndingPageElements.AddressList);
            addressUI = ele.getElementText(ele.getWebElement(LeadFormsLandingPageElements.installationAdress));
            //zipcode =ele.getElementText(ele.getWebElement(FencingLeadFormsLanndingPageElements.zipcode));
            //city=ele.getElementText(ele.getWebElement(FencingLeadFormsLanndingPageElements.city));
            ele.setTextElement(ele.getWebElement(LeadFormsLandingPageElements.city), City);
            Reporting.report("Successfully entered City name value", Status.INFO);
            ele.clickElement(ele.getWebElement(LeadFormsLandingPageElements.stateArrow));
            ele.selectDropDownByText(ele.getWebElement(LeadFormsLandingPageElements.stateArrow), state);
            Reporting.report("Successfully Selected state name value", Status.INFO);
            ele.setTextElement(ele.getWebElement(LeadFormsLandingPageElements.zipcode), Zipcode);
            Reporting.report("Successfully Entered Zipcode value", Status.INFO);
            ele.setTextElement(ele.getWebElement(LeadFormsLandingPageElements.phoneNum), phoneNo);
            Reporting.report("Successfully entered phone number value", Status.INFO);
            ele.setTextElement(ele.getWebElement(LeadFormsLandingPageElements.email), email);
            Reporting.report("Successfully entered email value", Status.INFO);
            if (timeline.equalsIgnoreCase("Right now")) {
                ele.scrollUntilElementIsClickable(ele.getWebElement(LeadFormsLandingPageElements.timelinerightnow));
                ele.clickElement(ele.getWebElement(LeadFormsLandingPageElements.timelinerightnow));
                Reporting.report("selected timeline 'Right now'  radio button", Status.INFO);
            } else if (timeline.equalsIgnoreCase("1 - 3 Months")) {
                ele.scrollUntilElementIsClickable(ele.getWebElement(LeadFormsLandingPageElements.timeline1to3Months));
                ele.clickElement(ele.getWebElement(LeadFormsLandingPageElements.timeline1to3Months));
                Reporting.report("selected timeline '1 - 3 Months'  radio button", Status.INFO);
            } else if (timeline.equalsIgnoreCase("3 - 6 Months")) {
                ele.scrollUntilElementIsClickable(ele.getWebElement(LeadFormsLandingPageElements.timeline3to6Months));
                ele.clickElement(ele.getWebElement(LeadFormsLandingPageElements.timeline3to6Months));
                Reporting.report("selected timeline '3 - 6 Months'  radio button", Status.INFO);
            } else if (timeline.equalsIgnoreCase("6+ Months")) {
                ele.scrollUntilElementIsClickable(ele.getWebElement(LeadFormsLandingPageElements.timeline6Months));
                ele.clickElement(ele.getWebElement(LeadFormsLandingPageElements.timeline6Months));
                Reporting.report("selected timeline '6+ Months'  radio button", Status.INFO);
            } else {
                Reporting.report("Could not select the timeline Radio button", Status.FAIL);
            }
            if (budget.equalsIgnoreCase("Under $5K")) {
                ele.scrollUntilElementIsClickable(ele.getWebElement(LeadFormsLandingPageElements.budgetunder5k));
                ele.clickElement(ele.getWebElement(LeadFormsLandingPageElements.budgetunder5k));
                Reporting.report("selected Under $5K radio button", Status.INFO);
            } else if (budget.equalsIgnoreCase("$5K to $10K")) {
                ele.scrollUntilElementIsClickable(ele.getWebElement(LeadFormsLandingPageElements.budget5kto10k));
                ele.clickElement(ele.getWebElement(LeadFormsLandingPageElements.budget5kto10k));
                Reporting.report("selected  $5K to $10K radio button", Status.INFO);
            } else if (budget.equalsIgnoreCase("$10K to $20K")) {
                ele.scrollUntilElementIsClickable(ele.getWebElement(LeadFormsLandingPageElements.budget10kto20k));
                ele.clickElement(ele.getWebElement(LeadFormsLandingPageElements.budget10kto20k));
                Reporting.report("selected $10K to $20K radio button", Status.INFO);
            } else if (budget.equalsIgnoreCase("$20K to $30K")) {
                ele.scrollUntilElementIsClickable(ele.getWebElement(LeadFormsLandingPageElements.budget20kto30k));
                ele.clickElement(ele.getWebElement(LeadFormsLandingPageElements.budget20kto30k));
                Reporting.report("selected $20K to $30K radio button", Status.INFO);
            } else if (budget.equalsIgnoreCase("$30K+")) {
                ele.scrollUntilElementIsClickable(ele.getWebElement(LeadFormsLandingPageElements.budget30kplus));
                ele.clickElement(ele.getWebElement(LeadFormsLandingPageElements.budget30kplus));
                Reporting.report("selected $30K+ radio button", Status.INFO);
            } else {
                Reporting.report("Could not select the budget Radio button", Status.FAIL);
            }
            ele.scrollUntilElementIsClickable(ele.getWebElement(LeadFormsLandingPageElements.descriptionText));
            ele.setTextElement(ele.getWebElement(LeadFormsLandingPageElements.descriptionText), description);
            Reporting.report("Successfully entered description text value", Status.INFO);
            ele.clickElement(ele.getWebElement(LeadFormsLandingPageElements.NextBtn));
            Reporting.report("Successfully clicked on 'Next' button", Status.INFO);
            ele.waitForElementToBeVisible((LeadFormsScheduleConsultationElements.requestConsultaionHeader));
            Assert.assertEquals(ele.getElementText(ele.getWebElement(LeadFormsScheduleConsultationElements.requestConsultaionHeader)), "Request FREE Virtual Consultation");
            Reporting.report("Information supplied successfully in Contact information page", Status.PASS);
        } catch (Exception e) {
            Reporting.report("Could not navigate to schedule confirmation page", Status.FAIL);
        }
    }

    public void VerifyNextButtonInContactInformationPage() {
        try {
            ele.scrollUntilElementIsClickable(ele.getWebElement(LeadFormsLandingPageElements.NextBtn));
            ele.clickElement(ele.getWebElement(LeadFormsLandingPageElements.NextBtn));
            Reporting.report("Successfully clicked on Next button", Status.INFO);
            if(driver.getCurrentUrl().contains("counter")){
                ele.scrollUntilElementIsClickable(ele.getWebElement(LeadFormsScheduleConsultationElements.requestConsultaionHeader));
                ele.waitForElementToBeVisible((LeadFormsScheduleConsultationElements.requestConsultaionHeader));
                Reporting.report("Schedule Consultation header is visible after clicking on 'Next' button.", Status.INFO);
                Assert.assertEquals(ele.getElementText(ele.getWebElement(LeadFormsScheduleConsultationElements.requestConsultaionHeader)), "Request FREE Virtual Consultation");

            }
            else{
                ele.scrollUntilElementIsClickable(ele.getWebElement(LeadFormsScheduleConsultationElements.scheduleConsultaionHeader));
                ele.waitForElementToBeVisible((LeadFormsScheduleConsultationElements.scheduleConsultaionHeader));
                Reporting.report("Schedule Consultation header is visible after clicking on 'Next' button.", Status.INFO);
                Assert.assertEquals(ele.getElementText(ele.getWebElement(LeadFormsScheduleConsultationElements.scheduleConsultaionHeader)), "Schedule Consultation");

            }
            Reporting.report("Next button verified successfully in Contact information page", Status.PASS);
        } catch (Exception e) {
            Reporting.report("Next button functionality in contact information not working successfully", Status.FAIL);
        }
    }

}

