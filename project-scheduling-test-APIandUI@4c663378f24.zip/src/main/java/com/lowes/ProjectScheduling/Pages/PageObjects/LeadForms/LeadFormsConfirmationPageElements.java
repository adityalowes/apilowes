package com.lowes.ProjectScheduling.Pages.PageObjects.LeadForms;

public interface LeadFormsConfirmationPageElements {

    String ConfirmationHeader="//*[@class='alert-title']";
    String ConfirmationSubHeader="//*[@class='alert-subtitle']";
    String emailText ="//p[contains(text(),'receive an email')]";
    String ManageappointmentLink = "//p[contains(text(),'receive an email')]//a";
    String ConsultationDetailsHeader = "//*[text()='Consultation Details']";
    String NameValue="//*[contains(@class,'icon-account')]/parent::div//span";
    String dateHeader = "//*[contains(@class,'icon-calendar')]/parent::div/parent::div/p";
    String dateValue = "//*[contains(@class,'icon-calendar')]/parent::div//span";
    String timeHeader= "//*[contains(@class,'icon-history')]/parent::div/parent::div/p";
    String timeValue = "//*[contains(@class,'icon-history')]/parent::div//span";
    String AddressHeader = "//*[contains(@class,'icon-location')]/parent::div/parent::div/parent::div/p";
    String address = "//*[contains(@class,'icon-location')]/parent::div/following-sibling::div";
    String beforeConsultationHeader = "//*[contains(text(),'Before Your Consultation')]";
    String adultImage= "//*[@alt='Adults']";
    String adultImageText="//*[@alt='Adults']/parent::p/following-sibling::p";
    String PetsImage="//*[@alt='Pets']";
    String PetsImageText="//*[@alt='Pets']/parent::p/following-sibling::p";
    String SpaceImage="//*[@alt='Space']";
    String SpaceImageText="//*[@alt='Space']/parent::p/following-sibling::p";


}
