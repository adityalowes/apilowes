package com.lowes.ProjectScheduling.Pages.PageObjects.LeadForms;

public interface LeadFormsLandingPageElements {

    String searchZipCode = "//input[contains(@placeholder,'Code')]";
    String arrowBtb ="//button[@type='button'and contains(@class,'rightArrowBtn')]";
    String setAsMyStoreBtn = "//span[@data-id='sc-set-as-my-store']";

    String getstarttedHeader = "//*[contains(text(),'Get Started With Your ')]";
    String imageEntercontact = "//img[@alt='Contact and Project Information']";
    String EnterContactText = "//span[contains(text(),'Enter Contact')]";
    String firstname = "//input[@aria-label='FirstName']";
    String lastname = "//input[@aria-label='LastName']";
    String installationAdress = "//input[@aria-label='address1']";
    String AddApartmentLink = "//span[contains(text(),'Add Apartment')]";
    String AddressList="//div[@data-selector='address-list-item']";
    String ManualAddress="//span[contains(text(),'Enter Address Manually')]";
    String city = "//input[@aria-label='city']";
    String stateDrpDwnBtn = "//select[@data-testid='State']/..";
    String listOfStates = "//select[@data-testid='State']";
    String zipcode = "//input[@aria-label='zipcode']";
    String phoneNum = "//input[@aria-label='phoneNumber']";
    String email = "//input[@aria-label='emailAddress']";
    String stateArrow = "//select[@aria-label='state']";
    String stateDropdown = "//select[@aria-label='state']//option";
    String phoenypeArrow = "//select[@aria-label='phoneType']";
    String phoneTypeDropdown = "//select[@aria-label='phoneType']//option";
    String describeHeader = "//*[contains(text(),'Briefly describe your project.')]";
    String descriptionText = "//*[@aria-label='projectDescription']";
    String AddSalesID = "//*[contains(text(),'Add Sales ID')]";
    String NextBtn = "//span[contains(text(),'Next')]";
    String State = "";
    String timelinerightnow = "//input[@value='Right Now']/parent::span";
    String timeline1to3Months = "//input[@value='1-3 Months']/parent::span";
    String timeline3to6Months = "//input[@value='3-6 Months']/parent::span";
    String timeline6Months = "//input[@value='6+ Months']/parent::span";
    String budgetunder5k = "//input[@value='Under $5K']/parent::span";
    String budget5kto10k = "//input[@value='$5K-10K']/parent::span";
    String budget10kto20k = "//input[@value='$10K-20K']/parent::span";
    String budget20kto30k = "//input[@value='$20K-30K']/parent::span";
    String budget30kplus = "//input[@value='$30K+']/parent::span";

}