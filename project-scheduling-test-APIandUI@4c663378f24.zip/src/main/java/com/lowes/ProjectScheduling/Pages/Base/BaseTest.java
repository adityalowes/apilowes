package com.lowes.ProjectScheduling.Pages.Base;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.JsonFormatter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.lowes.ProjectScheduling.Pages.PageActions.LeadForms.*;
import com.lowes.ProjectScheduling.Utils.CommonUtils.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static com.lowes.ProjectScheduling.Utils.CommonUtils.Reporting.getBase;

public class BaseTest implements ITestListener {

    LocalDateTime currentTime = LocalDateTime.now();
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss");
    String timestamp = currentTime.format(formatter);

    public static WebDriver driver;
   // public static ThreadLocal<WebDriver> threadLocalDriver = new ThreadLocal<>();
    public ExtentSparkReporter sparkReporter;
    //public ExtentHtmlReporter extentHtmlReporter;
    public static ExtentReports extent;
    public static ExtentTest logger;

    public static JsonFormatter json;

    public LeadFormsContactInformationPage leadFormLandingPage;
    public LeadFormsScheduleConfirmationPage leadFormScheduleConfirmationPage;
    public LeadFormsConsultationConfirmationPage leadFormConsultationConfirmationPage;




    @BeforeTest
    @Parameters("browser")
    public void beforeTest(String browser)  {
        sparkReporter = new ExtentSparkReporter(System.getProperty("user.dir") + File.separator + "reports" + File.separator + "AutomationReport_" + timestamp + ".html");
        extent = new ExtentReports();
        // json = new JsonFormatter(System.getProperty("user.dir") + File.separator + "reports" + File.separator + "AutomationReportJSON_" + timestamp + ".json");
        try {
            extent.createDomainFromJsonArchive(System.getProperty("user.dir") + File.separator + "reports" + File.separator + "AutomationReportJSON_" + timestamp + ".json");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        extent.attachReporter(sparkReporter,json);
        //sparkReporter.
        sparkReporter.config().setTheme(Theme.DARK);
        // sparkReporter.filter().;
        extent.setSystemInfo("HostName", "LocalHost");
        extent.setSystemInfo("UserName", "Pooja");
        sparkReporter.config().setDocumentTitle("Automation Report");
        sparkReporter.config().setReportName("Measure Request Tests Results");
        // sparkReporter.setAppendExisting(true);
        setupDriver(browser);
        driver.manage().window().maximize();
      //  threadLocalDriver.get().manage().window().maximize();

    }

    @BeforeClass
    public void initiatePageObjects() {

        leadFormLandingPage = new LeadFormsContactInformationPage();
        leadFormScheduleConfirmationPage = new LeadFormsScheduleConfirmationPage();
        leadFormConsultationConfirmationPage = new LeadFormsConsultationConfirmationPage();

    }

    @BeforeMethod
    public void beforeMethod(Method testMethod) {
        logger = extent.createTest(testMethod.getName());
       // threadLocalDriver.get().get(CommonUtils.getProperty("stageURL"));
       driver.get(CommonUtils.getProperty("stageURL"));
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
     //   threadLocalDriver.get().manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

    }




    @AfterMethod
    public void afterMethod(ITestResult result) {
        String filepath = System.getProperty("user.dir") + File.separator + "reports" + File.separator + "screenshots" + File.separator + result.getMethod().getMethodName() + ".png";

        if (result.getStatus() == ITestResult.FAILURE) {
            logger.log(Status.FAIL, MarkupHelper.createLabel(result.getName() + " - Test Case Failed", ExtentColor.RED));
            logger.fail("Validation Failed : " + result.getThrowable(), MediaEntityBuilder.createScreenCaptureFromBase64String(getBase()).build());
        } else if (result.getStatus() == ITestResult.SKIP) {
            logger.log(Status.SKIP, MarkupHelper.createLabel(result.getName() + " - Test Case Skipped", ExtentColor.YELLOW));
            logger.skip("Validation Skipped :" + result.getThrowable(), MediaEntityBuilder.createScreenCaptureFromBase64String(getBase()).build());
        } else if (result.getStatus() == ITestResult.SUCCESS) {
            logger.log(Status.PASS, MarkupHelper.createLabel(result.getName() + " - Test Case PASS", ExtentColor.GREEN));
            logger.pass("Validation Passed ", MediaEntityBuilder.createScreenCaptureFromBase64String(getBase()).build());
        }
        driver.manage().deleteAllCookies();
      //  threadLocalDriver.get().manage().deleteAllCookies();

    }

    @AfterTest
    public void afterTest() {
        driver.quit();
       // threadLocalDriver.get().quit();
        extent.flush();
    }

    public void setupDriver(String browser) {
        if (browser.equalsIgnoreCase("chrome")) {
            ChromeOptions options = new ChromeOptions();
            options.addExtensions(new File("7.0.1_0.crx"));
            WebDriverManager.chromedriver().clearDriverCache().setup();
           // threadLocalDriver.set(new ChromeDriver());
            driver = new ChromeDriver(options);
          //  driver = new ChromeDriver();

        } else if (browser.equalsIgnoreCase("firefox")) {
            WebDriverManager.firefoxdriver().setup();
            driver = new FirefoxDriver();
        } else if (browser.equalsIgnoreCase("edge")) {
            WebDriverManager.edgedriver().setup();
            driver = new EdgeDriver();
        }

    }


    public static void captureScreenshot(String tname) throws IOException {
        TakesScreenshot ts = (TakesScreenshot) driver;
       // TakesScreenshot ts = (TakesScreenshot) threadLocalDriver.get();
        File src = ts.getScreenshotAs(OutputType.FILE);
        String dest = System.getProperty("user.dir") + File.separator + "reports" + File.separator + "screenshots" + File.separator + tname + ".png";
        File target = new File(dest);
        FileUtils.copyFile(src, target);
        logger.info("Refer below screenshot", MediaEntityBuilder.createScreenCaptureFromPath(dest).build());
    }

}
