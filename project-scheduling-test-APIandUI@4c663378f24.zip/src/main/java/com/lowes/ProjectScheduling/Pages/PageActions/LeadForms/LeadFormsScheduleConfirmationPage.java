package com.lowes.ProjectScheduling.Pages.PageActions.LeadForms;

import com.aventstack.extentreports.Status;
import com.lowes.ProjectScheduling.Pages.PageObjects.LeadForms.LeadFormsLandingPageElements;
import com.lowes.ProjectScheduling.Pages.PageObjects.LeadForms.LeadFormsScheduleConsultationElements;
import com.lowes.ProjectScheduling.Utils.CommonUtils.Reporting;
import com.lowes.ProjectScheduling.Utils.UIUtils.ElementFetch;
import org.testng.asserts.SoftAssert;

import static com.lowes.ProjectScheduling.Pages.Base.BaseTest.driver;
import static com.lowes.ProjectScheduling.Pages.PageActions.LeadForms.LeadFormsContactInformationPage.addressUI;

public class LeadFormsScheduleConfirmationPage {

    SoftAssert softAssert = new SoftAssert();
    ElementFetch ele = new ElementFetch();
    static String timeUI;
    static String dateUI;
    static String AddressUI;
    static String formattedDateUI;

    static String ChooseDateHeader;
    static String ChooseTimeWindowHeader;

    public void VerifyBackButtonInScheduleConfirmationPage() {
        try {
            ele.scrollUntilElementIsClickable(ele.getWebElement(LeadFormsScheduleConsultationElements.BackBtn));
            ele.clickElement(ele.getWebElement(LeadFormsScheduleConsultationElements.BackBtn));
            Reporting.report("Successfully clicked on Back button", Status.INFO);
            ele.scrollUntilElementIsClickable(ele.getWebElement(LeadFormsLandingPageElements.EnterContactText));
            String EnterContactText = ele.getElementText(ele.getWebElement(LeadFormsLandingPageElements.EnterContactText));
            Reporting.report("Header of Contact Information page is visible after clicking ob 'Back' button.", Status.INFO);
            softAssert.assertEquals(EnterContactText, "Enter Contact & Project Information", "User did not navigate to Contact Information page after clicking on 'Back' button");
            Reporting.report("Back button verified successfully in Contact information page", Status.PASS);
        } catch (Exception e) {
            Reporting.report("Back button functionality in schedule consultation not working successfully", Status.FAIL);
        }
        softAssert.assertAll();
    }


    public void VerifyScheduleConfirmationPage(String firstName, String lastName, String phoneNo, String email, String description, String date) {
        try {
            if (driver.getCurrentUrl().contains("counter"))
                ele.scrollUntilElementIsClickable(ele.getWebElement(LeadFormsScheduleConsultationElements.requestConsultaionHeader));
            else
                ele.scrollUntilElementIsClickable(ele.getWebElement(LeadFormsScheduleConsultationElements.scheduleConsultaionHeader));
            String name = ele.getElementText(ele.getWebElement(LeadFormsScheduleConsultationElements.NameValue));
            softAssert.assertEquals(name, firstName + " " + lastName, "Name dint match");
            Reporting.report("Name fetched from UI " + name, Status.INFO);
            AddressUI = ele.getElementText(ele.getWebElement(LeadFormsScheduleConsultationElements.AddressValue));
            softAssert.assertNotNull(AddressUI, "Address could not be picked from UI");
            Reporting.report("Address fetched from UI " + AddressUI, Status.INFO);
            if (!AddressUI.contains(addressUI)) {
                softAssert.assertTrue(AddressUI.contains(addressUI), "Address displayed on UI in schedule consultation screen is not correct");
                Reporting.report("Address displayed in UI is not correct " + AddressUI, Status.FAIL);
            }
            String phoneNum = ele.getElementText(ele.getWebElement(LeadFormsScheduleConsultationElements.PhoneNumValue));
            softAssert.assertEquals(phoneNum, phoneNo, "Phone number dint match");
            Reporting.report("Phone number fetched from UI " + phoneNum, Status.INFO);
            String emailTextFromUI = ele.getElementText(ele.getWebElement(LeadFormsScheduleConsultationElements.emailAddressValue));
            softAssert.assertEquals(emailTextFromUI, email, "email address dint match");
            Reporting.report("Email address fetched from UI " + email, Status.INFO);
            String descriptionTextfromUI = ele.getElementText(ele.getWebElement(LeadFormsScheduleConsultationElements.projectDescriptionValue));
            softAssert.assertEquals(descriptionTextfromUI, description, "Description text dint match");
            Reporting.report("Description text fetched from UI " + description, Status.INFO);
            if (driver.getCurrentUrl().contains("counter")) {
                ChooseDateHeader = ele.getElementText(ele.getWebElement(LeadFormsScheduleConsultationElements.ChooseADayHeaderKitchen));
                softAssert.assertEquals(ChooseDateHeader, "Select a Date.", "Choose a day header text dint match");
                Reporting.report("Choose a day header text fetched from UI " + ChooseDateHeader, Status.INFO);
                ChooseTimeWindowHeader = ele.getElementText(ele.getWebElement(LeadFormsScheduleConsultationElements.ChosseTimeHaederKitchen));
                softAssert.assertEquals(ChooseTimeWindowHeader, "Select a Time.", "Choose a time window header text dint match");
                Reporting.report("Choose a time window header text fetched from UI " + ChooseTimeWindowHeader, Status.INFO);
                ele.scrollUntilElementIsClickable(ele.getWebElement(LeadFormsScheduleConsultationElements.DatePickerKitchen));
                ele.jsClickElement(ele.getWebElement(LeadFormsScheduleConsultationElements.DatePickerKitchen));
                Reporting.report("Clicked on  day picker", Status.INFO);
            } else {
                ChooseDateHeader = ele.getElementText(ele.getWebElement(LeadFormsScheduleConsultationElements.ChooseADayHeader));
                softAssert.assertEquals(ChooseDateHeader, "Choose a Day", "Choose a day header text dint match");
                Reporting.report("Choose a day header text fetched from UI " + ChooseDateHeader, Status.INFO);
                ChooseTimeWindowHeader = ele.getElementText(ele.getWebElement(LeadFormsScheduleConsultationElements.ChosseTimeHaeder));
                softAssert.assertEquals(ChooseTimeWindowHeader, "Choose a consultation window.", "Choose a time window header text dint match");
                Reporting.report("Choose a time window header text fetched from UI " + ChooseTimeWindowHeader, Status.INFO);
                ele.scrollUntilElementIsClickable(ele.getWebElement(LeadFormsScheduleConsultationElements.DatePickerKitchen));
                ele.jsClickElement(ele.getWebElement(LeadFormsScheduleConsultationElements.DatePickerKitchen));
                Reporting.report("Clicked on  day picker", Status.INFO);
            }

            if (date.equalsIgnoreCase("Random")) {
                dateUI = ele.selectAndReturnRandomElement(LeadFormsScheduleConsultationElements.AvailableDates);
                Reporting.report("selected a random date from available dates", Status.INFO);
                if (driver.getCurrentUrl().contains("counter")) {
                    formattedDateUI = dateUI;
                } else {
                    dateUI = ele.getElementText(ele.getWebElement(LeadFormsScheduleConsultationElements.DateValueNew));
                    formattedDateUI = dateUI.substring(4, dateUI.indexOf(",") - 2) + "," + dateUI.substring(dateUI.lastIndexOf(" "));
                }

            } else if (date.equalsIgnoreCase("Today")) {
                ele.jsClickElement(ele.getWebElement(LeadFormsScheduleConsultationElements.TodaysDateNew));
                Reporting.report("selected Today's date from date picker", Status.INFO);
                if (driver.getCurrentUrl().contains("counter")) {
                    dateUI = ele.getElementText(ele.getWebElement(LeadFormsScheduleConsultationElements.DateValueNew));
                } else {
                    dateUI = ele.getElementText(ele.getWebElement(LeadFormsScheduleConsultationElements.DateValueNew));
                }

            } else if (date.equalsIgnoreCase("Tomorrow")) {
                ele.jsClickElement(ele.getWebElement(LeadFormsScheduleConsultationElements.TomorrowsDate));
                Reporting.report("selected Tomorrow's date from date picker", Status.INFO);
                if (driver.getCurrentUrl().contains("counter")) {
                    dateUI = ele.getElementText(ele.getWebElement(LeadFormsScheduleConsultationElements.DateValueNew));
                } else {
                    dateUI = ele.getElementText(ele.getWebElement(LeadFormsScheduleConsultationElements.DateValue));
                }

            } else {
                Reporting.report("No time could be selected from date picker", Status.FAIL);
            }
            if (driver.getCurrentUrl().contains("counter")) {
                ele.jsClickElement(ele.getWebElement(LeadFormsScheduleConsultationElements.TimePickerNew));
                Reporting.report("Clicked on  time picker", Status.INFO);
            } else {
                ele.scrollUntilElementIsClickable(ele.getWebElement(LeadFormsScheduleConsultationElements.TimePickerNew));
                ele.jsClickElement(ele.getWebElement(LeadFormsScheduleConsultationElements.TimePickerNew));
                Reporting.report("Clicked on  time picker", Status.INFO);
            }
            if (driver.getCurrentUrl().contains("counter")) {
                ele.selectDropDownByIndex(ele.getWebElement(LeadFormsScheduleConsultationElements.TimePickerNew), 1);
            } else {
                ele.selectRandomElement(LeadFormsScheduleConsultationElements.TimeDropdownList);
                Reporting.report("selected a random time from available time slots", Status.INFO);
                timeUI = ele.getElementText(ele.getWebElement(LeadFormsScheduleConsultationElements.TimePickerNew));
            }
            ele.clickElement(ele.getWebElement(LeadFormsScheduleConsultationElements.ConfirmConsulatationBtn));
            Reporting.report("Clicked on  'Confirm Consultation' button", Status.INFO);
            String successMsg = ele.getElementText(ele.getWebElement(LeadFormsScheduleConsultationElements.ConfirmationHeader));
            softAssert.assertEquals(successMsg, "Your virtual consultation is confirmed.", "Consultation confirmation message is not displayed");
            String successMsgSubheader = ele.getElementText(ele.getWebElement(LeadFormsScheduleConsultationElements.ConfirmationSubHeader));
            softAssert.assertNotNull(successMsgSubheader);
            Reporting.report("Schedule confirmed and verified successfully", Status.PASS);

        } catch (Exception e) {
            Reporting.report("Could not schedule a consultation successfully", Status.FAIL);
        }
        softAssert.assertAll();
    }


}

