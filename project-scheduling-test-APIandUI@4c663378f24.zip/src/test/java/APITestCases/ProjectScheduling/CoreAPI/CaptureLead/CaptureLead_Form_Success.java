package APITestCases.ProjectScheduling.CoreAPI.CaptureLead;

import com.lowes.ProjectScheduling.Utils.APIUtils.AuthRequest_Appointment;
import com.lowes.ProjectScheduling.Utils.CommonUtils.CommonUtils;
import org.apache.commons.io.FileUtils;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;

import static com.lowes.ProjectScheduling.Utils.CommonUtils.FileNameConstants.*;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class CaptureLead_Form_Success extends AuthRequest_Appointment {


    @Test
    public void validate_CaptureLead_Success_Request() throws IOException {

        String accessToken = validate_Auth_Request_Appointment();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("CAPTURELEAD_REQUEST_BODY")), "utf-8");

        given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("CAPTURE_LEAD_URL")).
                header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_DISPLAYTYPE, HEADER_DISPLAYTYPE_FORM).
                header(HEADER_ROUTINGTYPE, HEADER_ROUTINGTYPE_IME).
                body(payload).
                when().
                post(CommonUtils.getProperty("CAPTURE_LEAD_URL")).
                then().
                log().all().
                //Assertions

                        statusCode(equalTo(201)).
//                body("timezone", Matchers.notNullValue()).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON);
//                body("slots.startTime[0]", Matchers.notNullValue()).
//                body("slots.startTime[0]", Matchers.notNullValue()).
//                body("leadId", Matchers.notNullValue()).body("slots", Matchers.notNullValue()).extract().response().asString();

//        JsonPath jsl = new JsonPath(extractHeader);
//        String leadId = jsl.getString("leadId");
//        String startDate = jsl.getString("slots.startTime[0]");
//        String endDate = jsl.getString("slots.endTime[0]");
//        Integer length = jsl.getList("slots.startTime").size();


    }


}
















