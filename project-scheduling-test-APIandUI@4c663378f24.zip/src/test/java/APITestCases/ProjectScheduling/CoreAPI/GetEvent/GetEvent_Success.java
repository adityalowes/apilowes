package APITestCases.ProjectScheduling.CoreAPI.GetEvent;

import com.lowes.ProjectScheduling.Utils.CommonUtils.CommonUtils;
import io.restassured.path.json.JsonPath;
import org.apache.commons.io.FileUtils;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;

import static APITestCases.ProjectScheduling.CoreAPI.CreateEvent.CreateEvent_Success.eventId;
import static com.lowes.ProjectScheduling.Utils.CommonUtils.FileNameConstants.*;
import static com.lowes.ProjectScheduling.Utils.CommonUtils.FileNameConstants.HEADER_APPLICATIONJSON;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class GetEvent_Success {

    @Test
    public void validate_GetEvent_Success_Request() throws IOException {

        // String accessToken = validate_Auth_Request_Event();

       String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("CREATE_EVENT_REQUEST_BODY")), "utf-8");
        String URL = CommonUtils.getProperty("GET_EVENT_URL")+eventId;
        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(URL).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bG1zLXVzZXI6TGVhZEAxMjM0").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").
                when().
                get().
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(200)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                body("eventid", Matchers.notNullValue()).
                body("createddatetime", Matchers.notNullValue()).
                body("updateddatetime", Matchers.notNullValue()).
                body("status", Matchers.notNullValue()).extract().response().asString();
        JsonPath response = new JsonPath(extractHeader);
        JsonPath request = new JsonPath(payload);
     Assert.assertEquals(response.getString("source"),request.getString("source"));
     Assert.assertEquals(response.getString("starttime"),request.getString("starttime"));
     Assert.assertEquals(response.getString("endtime"),request.getString("endtime"));
     Assert.assertEquals(response.getString("recurrence"),request.getString("recurrence"));
     Assert.assertEquals(response.getString("frequency"),request.getString("frequency"));
     Assert.assertEquals(response.getString("startdate"),request.getString("startdate"));
     Assert.assertEquals(response.getString("enddate"),request.getString("enddate"));
     Assert.assertEquals(response.getString("createdby"),request.getString("usersalesid"));
     Assert.assertEquals(response.getString("updatedby"),request.getString("usersalesid"));
     Assert.assertEquals(response.getString("title"),request.getString("title"));
     Assert.assertEquals(response.getString("description"),request.getString("description"));
     Assert.assertEquals(response.getString("type"),request.getString("type").toUpperCase());
     Assert.assertEquals(response.getString("timezone"),request.getString("timezone"));
     Assert.assertEquals(response.getString("usersalesid"),request.getString("usersalesid"));

    }
}