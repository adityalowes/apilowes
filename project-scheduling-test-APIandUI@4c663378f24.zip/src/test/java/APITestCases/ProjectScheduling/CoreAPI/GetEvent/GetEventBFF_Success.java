package APITestCases.ProjectScheduling.CoreAPI.GetEvent;

import com.lowes.ProjectScheduling.Utils.CommonUtils.CommonUtils;
import io.restassured.path.json.JsonPath;
import org.apache.commons.io.FileUtils;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;

import static APITestCases.ProjectScheduling.CoreAPI.CreateEvent.CreateEventBFF_Success.eventId;
import static APITestCases.ProjectScheduling.CoreAPI.CreateEvent.CreateEventBFF_Success.eventId1;
import static APITestCases.ProjectScheduling.CoreAPI.CreateEvent.CreateEventBFF_Success.eventId2;
import static APITestCases.ProjectScheduling.CoreAPI.CreateEvent.CreateEventBFF_Success.eventId3;
import static com.lowes.ProjectScheduling.Utils.CommonUtils.FileNameConstants.*;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class GetEventBFF_Success {

    @Test(priority = 3)
    public void validate_GetEvent_BFF_Success_RecurrantOverlappinhDayEvent_Request() throws IOException {
        int endDateCount = 1;
        int startDateCount = 0;
        // String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("CREATE_EVENT_BFF_REQUEST_BODY3")), "utf-8");
        String URL = CommonUtils.getProperty("GET_EVENT_BFF_URL") + eventId3;
        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(URL).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").
                when().
                get().
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(200)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                body("events[0].eventId", Matchers.notNullValue()).
                body("events[0].createdDateTime", Matchers.notNullValue()).
                body("events[0].updatedDateTime", Matchers.notNullValue()).
                body("events[0].status", Matchers.notNullValue()).extract().response().asString();
        JsonPath response = new JsonPath(extractHeader);
        JsonPath request = new JsonPath(payload);


        for (int i = 0; i < response.getInt("events.size()"); i++) {
            Assert.assertEquals(response.getString("events[" + i + "].sourceCode"), request.getString("event.sourceCode"));
            Assert.assertEquals(response.getString("events[" + i + "].startTime"), request.getString("event.startTime"));
            Assert.assertEquals(response.getString("events[" + i + "].endTime"), request.getString("event.endTime"));
            Assert.assertEquals(response.getString("events[" + i + "].isRecurring"), request.getString("event.isRecurring"));
            if (response.getString("events[0].isRecurring").equalsIgnoreCase("true")) {

                int index = request.getString("event.startDate").lastIndexOf("-") + 1;
                String dateprefix = request.getString("event.startDate").substring(0, index);
                int startDate = Integer.parseInt(request.getString("event.startDate").substring(index)) + startDateCount;
                int endDate = Integer.parseInt(request.getString("event.startDate").substring(index)) + endDateCount;
                String expectedStartDate = dateprefix + String.valueOf(startDate);
                String expectedEndDate = dateprefix + String.valueOf(endDate);
                Assert.assertEquals(response.getString("events[" + i + "].startDate"), expectedStartDate);
                Assert.assertEquals(response.getString("events[" + i + "].endDate"), expectedEndDate);
                Assert.assertEquals(response.getString("events[" + i + "].frequency"), request.getString("event.frequency").toUpperCase());
                endDateCount++;
                startDateCount++;
            } else {
                Assert.assertEquals(response.getString("events[" + i + "].startDate"), request.getString("event.startDate"));
                Assert.assertEquals(response.getString("events[" + i + "].endDate"), request.getString("event.endDate"));
                Assert.assertEquals(response.getString("events[" + i + "].frequency"), "NONE");

            }
            Assert.assertEquals(response.getString("events[" + i + "].createdBy"), request.getString("event.associateId"));
            Assert.assertEquals(response.getString("events[" + i + "].updatedBy"), request.getString("event.associateId"));
            Assert.assertEquals(response.getString("events[" + i + "].title"), request.getString("event.title"));
            Assert.assertEquals(response.getString("events[" + i + "].description"), request.getString("event.description"));
            Assert.assertEquals(response.getString("events[" + i + "].type"), request.getString("event.type"));
            Assert.assertEquals(response.getString("events[" + i + "].timeZone"), request.getString("event.timeZone"));
            Assert.assertEquals(response.getString("events[" + i + "].associateId"), request.getString("event.associateId"));
        }
    }

    @Test(priority = 2)
    public void validate_GetEvent_BFF_Success_NonRecurrantSingleDayEvent_Request() throws IOException {
        int count = 0;
        // String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("CREATE_EVENT_BFF_REQUEST_BODY2")), "utf-8");
        String URL = CommonUtils.getProperty("GET_EVENT_BFF_URL") + eventId2;
        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(URL).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").
                when().
                get().
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(200)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                body("events[0].eventId", Matchers.notNullValue()).
                body("events[0].createdDateTime", Matchers.notNullValue()).
                body("events[0].updatedDateTime", Matchers.notNullValue()).
                body("events[0].status", Matchers.notNullValue()).extract().response().asString();
        JsonPath response = new JsonPath(extractHeader);
        JsonPath request = new JsonPath(payload);


        for (int i = 0; i < response.getInt("events.size()"); i++) {
            {

                Assert.assertEquals(response.getString("events[" + i + "].sourceCode"), request.getString("event.sourceCode"));
                Assert.assertEquals(response.getString("events[" + i + "].startTime"), request.getString("event.startTime"));
                Assert.assertEquals(response.getString("events[" + i + "].endTime"), request.getString("event.endTime"));
                Assert.assertEquals(response.getString("events[" + i + "].isRecurring"), request.getString("event.isRecurring"));
                if (response.getString("events[0].isRecurring").equalsIgnoreCase("true")) {

                    int index = request.getString("event.startDate").lastIndexOf("-") + 1;
                    String dateprefix = request.getString("event.startDate").substring(0, index);
                    int date = Integer.parseInt(request.getString("event.startDate").substring(index)) + count;
                    String expectedDate = dateprefix + String.valueOf(date);
                    Assert.assertEquals(response.getString("events[" + i + "].startDate"), expectedDate);
                    Assert.assertEquals(response.getString("events[" + i + "].endDate"), expectedDate);
                    Assert.assertEquals(response.getString("events[" + i + "].frequency"), request.getString("event.frequency").toUpperCase());
                    count++;
                } else {
                    Assert.assertEquals(response.getString("events[" + i + "].startDate"), request.getString("event.startDate"));
                    Assert.assertEquals(response.getString("events[" + i + "].endDate"), request.getString("event.endDate"));
                    Assert.assertEquals(response.getString("events[" + i + "].frequency"), "NONE");

                }
                Assert.assertEquals(response.getString("events[" + i + "].createdBy"), request.getString("event.associateId"));
                Assert.assertEquals(response.getString("events[" + i + "].updatedBy"), request.getString("event.associateId"));
                Assert.assertEquals(response.getString("events[" + i + "].title"), request.getString("event.title"));
                Assert.assertEquals(response.getString("events[" + i + "].description"), request.getString("event.description"));
                Assert.assertEquals(response.getString("events[" + i + "].type"), request.getString("event.type"));
                Assert.assertEquals(response.getString("events[" + i + "].timeZone"), request.getString("event.timeZone"));
                Assert.assertEquals(response.getString("events[" + i + "].associateId"), request.getString("event.associateId"));
            }
        }
    }

    @Test(priority = 1)
    public void validate_GetEvent_BFF_Success_NonRecurrant_MultipleDayEvent_Request() throws IOException {
        int count = 0;
        // String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("CREATE_EVENT_BFF_REQUEST_BODY1")), "utf-8");
        String URL = CommonUtils.getProperty("GET_EVENT_BFF_URL") + eventId1;
        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(URL).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").
                when().
                get().
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(200)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                body("events[0].eventId", Matchers.notNullValue()).
                body("events[0].createdDateTime", Matchers.notNullValue()).
                body("events[0].updatedDateTime", Matchers.notNullValue()).
                body("events[0].status", Matchers.notNullValue()).extract().response().asString();
        JsonPath response = new JsonPath(extractHeader);
        JsonPath request = new JsonPath(payload);


        for (int i = 0; i < response.getInt("events.size()"); i++) {

            Assert.assertEquals(response.getString("events[" + i + "].sourceCode"), request.getString("event.sourceCode"));
            Assert.assertEquals(response.getString("events[" + i + "].startTime"), request.getString("event.startTime"));
            Assert.assertEquals(response.getString("events[" + i + "].endTime"), request.getString("event.endTime"));
            Assert.assertEquals(response.getString("events[" + i + "].isRecurring"), request.getString("event.isRecurring"));
            if (response.getString("events[0].isRecurring").equalsIgnoreCase("true")) {

                int index = request.getString("event.startDate").lastIndexOf("-") + 1;
                String dateprefix = request.getString("event.startDate").substring(0, index);
                int date = Integer.parseInt(request.getString("event.startDate").substring(index)) + count;
                String expectedDate = dateprefix + String.valueOf(date);
                Assert.assertEquals(response.getString("events[" + i + "].startDate"), expectedDate);
                Assert.assertEquals(response.getString("events[" + i + "].endDate"), expectedDate);
                Assert.assertEquals(response.getString("events[" + i + "].frequency"), request.getString("event.frequency").toUpperCase());
                count++;
            } else {
                Assert.assertEquals(response.getString("events[" + i + "].startDate"), request.getString("event.startDate"));
                Assert.assertEquals(response.getString("events[" + i + "].endDate"), request.getString("event.endDate"));
                Assert.assertEquals(response.getString("events[" + i + "].frequency"), "NONE");

            }
            Assert.assertEquals(response.getString("events[" + i + "].createdBy"), request.getString("event.associateId"));
            Assert.assertEquals(response.getString("events[" + i + "].updatedBy"), request.getString("event.associateId"));
            Assert.assertEquals(response.getString("events[" + i + "].title"), request.getString("event.title"));
            Assert.assertEquals(response.getString("events[" + i + "].description"), request.getString("event.description"));
            Assert.assertEquals(response.getString("events[" + i + "].type"), request.getString("event.type"));
            Assert.assertEquals(response.getString("events[" + i + "].timeZone"), request.getString("event.timeZone"));
            Assert.assertEquals(response.getString("events[" + i + "].associateId"), request.getString("event.associateId"));
        }
    }

    @Test(priority = 0)
    public void validate_GetEvent_BFF_Success_Recurrant_Request() throws IOException {
        int count = 0;
        // String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("CREATE_EVENT_BFF_REQUEST_BODY")), "utf-8");
        String URL = CommonUtils.getProperty("GET_EVENT_BFF_URL") + eventId;
        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(URL).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").
                when().
                get().
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(200)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                body("events[0].eventId", Matchers.notNullValue()).
                body("events[0].createdDateTime", Matchers.notNullValue()).
                body("events[0].updatedDateTime", Matchers.notNullValue()).
                body("events[0].status", Matchers.notNullValue()).extract().response().asString();
        JsonPath response = new JsonPath(extractHeader);
        JsonPath request = new JsonPath(payload);


        for (int i = 0; i < response.getInt("events.size()"); i++) {

            Assert.assertEquals(response.getString("events[" + i + "].sourceCode"), request.getString("event.sourceCode"));
            Assert.assertEquals(response.getString("events[" + i + "].startTime"), request.getString("event.startTime"));
            Assert.assertEquals(response.getString("events[" + i + "].endTime"), request.getString("event.endTime"));
            Assert.assertEquals(response.getString("events[" + i + "].isRecurring"), request.getString("event.isRecurring"));
            if (response.getString("events[0].isRecurring").equalsIgnoreCase("true")) {

                int index = request.getString("event.startDate").lastIndexOf("-") + 1;
                String dateprefix = request.getString("event.startDate").substring(0, index);
                int date = Integer.parseInt(request.getString("event.startDate").substring(index)) + count;
                String expectedDate = dateprefix + String.valueOf(date);
                Assert.assertEquals(response.getString("events[" + i + "].startDate"), expectedDate);
                Assert.assertEquals(response.getString("events[" + i + "].endDate"), expectedDate);
                Assert.assertEquals(response.getString("events[" + i + "].frequency"), request.getString("event.frequency").toUpperCase());
                count++;
            } else {
                Assert.assertEquals(response.getString("events[" + i + "].startDate"), request.getString("event.startDate"));
                Assert.assertEquals(response.getString("events[" + i + "].endDate"), request.getString("event.endDate"));
                Assert.assertEquals(response.getString("events[" + i + "].frequency"), "NONE");

            }
            Assert.assertEquals(response.getString("events[" + i + "].createdBy"), request.getString("event.associateId"));
            Assert.assertEquals(response.getString("events[" + i + "].updatedBy"), request.getString("event.associateId"));
            Assert.assertEquals(response.getString("events[" + i + "].title"), request.getString("event.title"));
            Assert.assertEquals(response.getString("events[" + i + "].description"), request.getString("event.description"));
            Assert.assertEquals(response.getString("events[" + i + "].type"), request.getString("event.type"));
            Assert.assertEquals(response.getString("events[" + i + "].timeZone"), request.getString("event.timeZone"));
            Assert.assertEquals(response.getString("events[" + i + "].associateId"), request.getString("event.associateId"));
        }
    }
}


