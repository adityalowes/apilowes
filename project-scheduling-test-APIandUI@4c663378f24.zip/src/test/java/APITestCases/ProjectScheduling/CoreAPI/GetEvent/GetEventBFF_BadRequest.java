package APITestCases.ProjectScheduling.CoreAPI.GetEvent;

import com.lowes.ProjectScheduling.Utils.CommonUtils.CommonUtils;
import io.restassured.path.json.JsonPath;
import org.apache.commons.io.FileUtils;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;

import static APITestCases.ProjectScheduling.CoreAPI.CreateEvent.CreateEventBFF_Success.*;
import static com.lowes.ProjectScheduling.Utils.CommonUtils.FileNameConstants.*;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class GetEventBFF_BadRequest {

    @Test(priority = 3)
    public void validate_GetEvent_BFF_BadRequest() throws IOException {

        // String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("CREATE_EVENT_BFF_REQUEST_BODY3")), "utf-8");
        String URL = "https://internal-east4.carbon-dev.gcp.lowes.com/leadtracker/v1/calendar/geteven/" + eventId3;
        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(URL).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").
                when().
                get().
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(404)).extract().response().asString();

    }


}


