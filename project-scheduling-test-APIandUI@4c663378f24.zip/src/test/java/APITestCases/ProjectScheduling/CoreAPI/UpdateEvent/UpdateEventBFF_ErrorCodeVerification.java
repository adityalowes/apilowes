package APITestCases.ProjectScheduling.CoreAPI.UpdateEvent;

import com.lowes.ProjectScheduling.Utils.APIUtils.AuthRequest_Event;
import com.lowes.ProjectScheduling.Utils.CommonUtils.CommonUtils;
import org.apache.commons.io.FileUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;

import static APITestCases.ProjectScheduling.CoreAPI.CreateEvent.CreateEventBFF_Success.eventId;
import static com.lowes.ProjectScheduling.Utils.CommonUtils.FileNameConstants.*;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class UpdateEventBFF_ErrorCodeVerification extends AuthRequest_Event {


    @Test(priority = 1)
    public void validate_UpdateEvent_BFF_AssociateIDErrorCodeVerification() throws IOException {

        String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("UPDATE_EVENT_BFF_INVALID_ASSOCIATE_REQUEST_BODY")), "utf-8");
        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().
                put(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"118\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Associate ID must contain only alphabets and numbers\""));

    }


    @Test(priority = 2)
    public void validate_UpdateEvent_BFF_AssociateIDMissingErrorCodeVerification() throws IOException {
        String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("UPDATE_EVENT_BFF_INVALID_ASSOCIATE_MISSING_REQUEST_BODY")), "utf-8");
        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().
                put(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"114\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Associate Id is missing\""));


    }

    @Test(priority = 3)
    public void validate_UpdateEvent_BFF_EndDateErrorVerification() throws IOException {
        String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("UPDATE_EVENT_BFF_INVALID_ENDDATE_REQUEST_BODY")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().

                put(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"120\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Invalid date format. Please use yyyy-MM-dd\""));

    }

    @Test(priority = 4)
    public void validate_CreateEvent_BFF_EndtDateMissingErrorVerification() throws IOException {

        String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("UPDATE_EVENT_BFF_INVALID_ENDDATE_MISSING_REQUEST_BODY")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().
                put(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"107\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"End date is missing\""));

    }

    @Test(priority = 5)
    public void validate_UpdateEvent_BFF_EndTimeErrorVerification() throws IOException {
        String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("UPDATE_EVENT_BFF_INVALID_ENDTIME_REQUEST_BODY")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().

                put(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"121\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Invalid time format. Please use HH:mm:SS\""));

    }

    @Test(priority = 6)
    public void validate_UpdateEvent_BFF_InvalidEndTimeErrorVerification() throws IOException {
        String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("UPDATE_EVENT_BFF_INVALID_ENDTIME_REQUEST_BODY1")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().

                put(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"116\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"End time cannot be lesser than or equal to start time\""));

    }

    @Test(priority = 7)
    public void validate_UpdateEvent_BFF_EndTimeMissingErrorVerification() throws IOException {
        String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("UPDATE_EVENT_BFF_INVALID_ENDTIME_MISSING_REQUEST_BODY")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().

                put(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"103\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"End time is missing\""));

    }

    @Test(priority = 8)
    public void validate_UpdateEvent_BFF_FrequencyErrorVerification() throws IOException {
        // String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("UPDATE_EVENT_BFF_INVALID_FREQUENCY_REQUEST_BODY")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().

                put(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"117\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"frequency should be one of [daily / weekly / monthly]\""));

    }

    @Test(priority = 9)
    public void validate_UpdateEvent_BFF_RecurranceChangeErrorVerification() throws IOException {
        String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("UPDATE_EVENT_BFF_INVALID_RECURRRANCE_CHANGE_REQUEST_BODY")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().

                put(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"117\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Recurrance cannot be updated\""));

    }

    @Test(priority = 10)
    public void validate_UpdateEvent_BFF_StartDateErrorVerification() throws IOException {
        String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("UPDATE_EVENT_BFF_INVALID_STARTDATE_REQUEST_BODY")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().

                put(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"120\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Invalid date format. Please use yyyy-MM-dd\""));

    }


    @Test(priority = 11)
    public void validate_UpdateEvent_BFF_StartDateMissingErrorVerification() throws IOException {
        // String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("UPDATE_EVENT_BFF_INVALID_STARTDATE_MISSING_REQUEST_BODY")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().

                put(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"106\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Start date is missing\""));

    }

    @Test(priority = 12)
    public void validate_UpdateEvent_BFF_StartTimeErrorVerification() throws IOException {
        String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("UPDATE_EVENT_BFF_INVALID_STARTTIME_REQUEST_BODY")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().

                put(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"121\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Invalid time format. Please use HH:mm:SS\""));

    }

    @Test(priority = 13)
    public void validate_UpdateEvent_BFF_StartTimeEndTimeSameErrorVerification() throws IOException {
        String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("UPDATE_EVENT_BFF_INVALID_STARTTIME_REQUEST_BODY1")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().

                put(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"116\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"End time cannot be lesser than or equal to start time\""));

    }

    @Test(priority = 14)
    public void validate_UpdateEvent_BFF_StartTimeMissingErrorVerification() throws IOException {
        String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("UPDATE_EVENT_BFF_INVALID_STARTTIME_MISSING_REQUEST_BODY")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().

                put(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"102\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Start time is missing\""));

    }

    @Test(priority = 15)
    public void validate_UpdateEvent_BFF_StatusChangeErrorVerification() throws IOException {
        String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("UPDATE_EVENT_BFF_INVALID_STATUS_CHANGE_REQUEST_BODY")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().

                put(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"102\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Status cannot be changed\""));

    }

    @Test(priority = 16)
    public void validate_UpdateEvent_BFF_TimezoneErrorVerification() throws IOException {
        String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("UPDATE_EVENT_BFF_INVALID_TIMEZONE_REQUEST_BODY")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().

                put(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"124\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Invalid timeZone format. The timeZone should be in the Zone Id format eg. America/New_York\""));

    }

    @Test(priority = 17)
    public void validate_UpdateEvent_BFF_TitleErrorVerification() throws IOException {
        String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("UPDATE_EVENT_BFF_INVALID_TITLE_REQUEST_BODY")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().

                put(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"109\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Title is mandatory\""));

    }

    @Test(priority = 18)
    public void validate_UpdateEvent_BFF_TypeErrorVerification() throws IOException {
        // String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("UPDATE_EVENT_BFF_INVALID_TYPE_REQUEST_BODY")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().

                put(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"119\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Type should be one of [Medical, Admin, Out of Office, Training, Lunch, Break, Other]\""));

    }

    @Test(priority = 19)
    public void validate_UpdateEvent_BFF_UpdatedDateTimeErrorVerification() throws IOException {
        String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("UPDATE_EVENT_BFF_INVALID_UPDATED_DATETIME_REQUEST_BODY")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().

                put(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"108\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Invalid time format. Please use YYYY-MM-DD HH:mm:SS\""));

    }


    @Test(priority = 20)
    public void validate_CreateEvent_BFF_endDateLesserErrorVerification() throws IOException {
        String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("UPDATE_EVENT_BFF_INVALID_STARTDATE_REQUEST_BODY1")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().

                put(CommonUtils.getProperty("UPDATE_EVENT_BFF_URL") + eventId).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"115\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"End date cannot be lesser than start date\""));

    }


}
















