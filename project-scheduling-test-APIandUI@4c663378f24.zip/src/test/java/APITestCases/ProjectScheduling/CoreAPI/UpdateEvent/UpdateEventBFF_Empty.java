package APITestCases.ProjectScheduling.CoreAPI.UpdateEvent;

import APITestCases.ProjectScheduling.CoreAPI.CreateEvent.CreateEvent_Success;
import com.lowes.ProjectScheduling.Utils.APIUtils.AuthRequest_Event;
import com.lowes.ProjectScheduling.Utils.CommonUtils.CommonUtils;
import org.testng.annotations.Test;

import java.io.IOException;

import static APITestCases.ProjectScheduling.CoreAPI.CreateEvent.CreateEventBFF_Success.eventId;
import static com.lowes.ProjectScheduling.Utils.CommonUtils.FileNameConstants.*;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class UpdateEventBFF_Empty extends AuthRequest_Event {


    @Test
    public void validate_UpdateEventBFF_Empty_Request() throws IOException {

      //  String accessToken = validate_Auth_Request_Event();

        String payload = "";
        String URL = CommonUtils.getProperty("UPDATE_EVENT_BFF_URL")+ eventId;
        given().relaxedHTTPSValidation().
                baseUri(URL).
              //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                      header(HEADER_AUTHORIZATION,  "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                body(payload).
                when().
                put(URL).
                then().
                log().all().
                //Assertions

                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON);


    }


}
















