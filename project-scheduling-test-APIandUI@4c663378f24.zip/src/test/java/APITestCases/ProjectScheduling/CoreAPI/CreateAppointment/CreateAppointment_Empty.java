package APITestCases.ProjectScheduling.CoreAPI.CreateAppointment;
import com.lowes.ProjectScheduling.Utils.APIUtils.GetSlots_MethodCall;
import com.lowes.ProjectScheduling.Utils.CommonUtils.CommonUtils;
import org.testng.annotations.Test;

import java.io.IOException;

import static com.lowes.ProjectScheduling.Utils.CommonUtils.FileNameConstants.*;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class CreateAppointment_Empty extends GetSlots_MethodCall {

    @Test
    public void validate_Create_Appointment_Empty_Request() throws IOException {

        String Getslotsreturn[] = validate_GetSlots_Request();

        String accessToken = validate_Auth_Request_Appointment();

        String createAppointmentPayload = "";

        given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("CREATE_APPT_URL")).
                header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                body(createAppointmentPayload).
                when().
                post(CommonUtils.getProperty("CREATE_APPT_URL")).
                then().
                log().all().
                statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON);



    }
}




















