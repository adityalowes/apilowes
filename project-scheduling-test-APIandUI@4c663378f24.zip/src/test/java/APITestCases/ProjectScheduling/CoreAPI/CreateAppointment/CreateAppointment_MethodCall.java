package APITestCases.ProjectScheduling.CoreAPI.CreateAppointment;

import com.lowes.ProjectScheduling.Utils.APIUtils.GetSlots_MethodCall;
import com.lowes.ProjectScheduling.Utils.CommonUtils.CommonUtils;
import org.apache.commons.io.FileUtils;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;

import static com.lowes.ProjectScheduling.Utils.CommonUtils.FileNameConstants.*;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class CreateAppointment_MethodCall extends GetSlots_MethodCall {

    @Test
    public String[] validate_Create_Appointment_MethodCall() throws IOException {
        String Getslotsreturn[] = validate_GetSlots_Request();

        String accessToken = validate_Auth_Request_Appointment();

        String createAppointmentPayload = FileUtils.readFileToString(new File(CommonUtils.getProperty("CREATE_APPOINTMENT_REQUEST_BODY")), "utf-8");

        createAppointmentPayload = createAppointmentPayload.replace("LeadIDDynamic", Getslotsreturn[0]);
        createAppointmentPayload = createAppointmentPayload.replace("StartdateDynamic", Getslotsreturn[1]);
        createAppointmentPayload = createAppointmentPayload.replace("EnddateDynamic", Getslotsreturn[2]);

        given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("CREATE_APPT_URL")).
                header(HEADER_AUTHORIZATION, HEADER_BEARER+ accessToken).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                body(createAppointmentPayload).
                when().
                post(CommonUtils.getProperty("CREATE_APPT_URL")).
                then().
                log().all().
                statusCode(equalTo(201)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON);
        return new String[]{Getslotsreturn[1], Getslotsreturn[2]};
    }
}



















