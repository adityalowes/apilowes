package APITestCases.ProjectScheduling.CoreAPI.CancelAppt;

import APITestCases.ProjectScheduling.CoreAPI.CreateAppointment.CreateAppointment_MethodCall;
import com.lowes.ProjectScheduling.Utils.CommonUtils.CommonUtils;
import org.apache.commons.io.FileUtils;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;

import static com.lowes.ProjectScheduling.Utils.CommonUtils.FileNameConstants.*;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class CancelAppointment_Success extends CreateAppointment_MethodCall {

    @Test
    public void validate_Cancel_Appointment_Success_Request() throws IOException {

        String GetAppointmentDetails[] = validate_Create_Appointment_MethodCall();

        String accessToken = validate_Auth_Request_Appointment();

        String cancelAppointmentPayload = FileUtils.readFileToString(new File(CommonUtils.getProperty("CANCEL_APPOINTMENT_REQUEST_BODY")), "utf-8");

        //cancelAppointmentPayload = cancelAppointmentPayload.replace("2024-04-25T00:00:00.000Z", GetAppointmentDetails[0]);
        cancelAppointmentPayload = cancelAppointmentPayload.replace("StartdateDynamic", GetAppointmentDetails[0]);
        cancelAppointmentPayload = cancelAppointmentPayload.replace("EnddateDynamic", GetAppointmentDetails[1]);

        given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("CANCEL_APPOINTMENT_URL")).
                header(HEADER_AUTHORIZATION, HEADER_BEARER+ accessToken).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                body(cancelAppointmentPayload).
                when().
                post(CommonUtils.getProperty("CANCEL_APPOINTMENT_URL")).
                then().
                log().all().
                statusCode(equalTo(200)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON);

    }
}



















