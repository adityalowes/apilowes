package APITestCases.ProjectScheduling.CoreAPI.CreateEvent;

import com.lowes.ProjectScheduling.Utils.APIUtils.AuthRequest_Event;
import com.lowes.ProjectScheduling.Utils.CommonUtils.CommonUtils;
import io.restassured.path.json.JsonPath;
import org.apache.commons.io.FileUtils;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;

import static com.lowes.ProjectScheduling.Utils.CommonUtils.FileNameConstants.*;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class CreateEvent_Success extends AuthRequest_Event {

    public static String eventId = "";

    @Test
    public void validate_CreateEvent_Success_Request() throws IOException {

        // String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("CREATE_EVENT_REQUEST_BODY")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("CREATE_EVENT_URL")).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bG1zLXVzZXI6TGVhZEAxMjM0").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().
                post(CommonUtils.getProperty("CREATE_EVENT_URL")).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(201)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                body("eventId", Matchers.notNullValue()).
                body("createdDateTime", Matchers.notNullValue()).
                body("updatedDateTime", Matchers.notNullValue()).
                body("status", Matchers.notNullValue()).extract().response().asString();

        JsonPath response = new JsonPath(extractHeader);
        JsonPath request = new JsonPath(payload);
        eventId = response.getString("eventid");
        Assert.assertEquals(response.getString("source"),request.getString("source"));
        Assert.assertEquals(response.getString("starttime"),request.getString("starttime"));
        Assert.assertEquals(response.getString("endtime"),request.getString("endtime"));
        Assert.assertEquals(response.getString("recurrence"),request.getString("recurrence"));
        Assert.assertEquals(response.getString("frequency"),request.getString("frequency"));
        Assert.assertEquals(response.getString("startdate"),request.getString("startdate"));
        Assert.assertEquals(response.getString("enddate"),request.getString("enddate"));
        Assert.assertEquals(response.getString("createdby"),request.getString("usersalesid"));
        Assert.assertEquals(response.getString("updatedby"),request.getString("usersalesid"));
        Assert.assertEquals(response.getString("title"),request.getString("title"));
        Assert.assertEquals(response.getString("description"),request.getString("description"));
        Assert.assertEquals(response.getString("type"),request.getString("type").toUpperCase());
        Assert.assertEquals(response.getString("timezone"),request.getString("timezone"));
        Assert.assertEquals(response.getString("usersalesid"),request.getString("usersalesid"));

    }
}
















