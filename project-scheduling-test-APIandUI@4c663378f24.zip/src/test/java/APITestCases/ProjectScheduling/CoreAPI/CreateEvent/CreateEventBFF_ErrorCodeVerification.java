package APITestCases.ProjectScheduling.CoreAPI.CreateEvent;

import com.lowes.ProjectScheduling.Utils.APIUtils.AuthRequest_Event;
import com.lowes.ProjectScheduling.Utils.CommonUtils.CommonUtils;
import io.restassured.path.json.JsonPath;
import org.apache.commons.io.FileUtils;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;

import static com.lowes.ProjectScheduling.Utils.CommonUtils.FileNameConstants.*;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class CreateEventBFF_ErrorCodeVerification extends AuthRequest_Event {

    public static String eventId = "";

    @Test(priority = 1)
    public void validate_CreateEvent_BFF_MissingErrorCodeVerification() throws IOException {
        int count = 0;
        // String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("CREATE_EVENT_BFF_INVALID_REQUEST_BODY")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("CREATE_EVENT_BFF_URL")).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().
                post(CommonUtils.getProperty("CREATE_EVENT_BFF_URL")).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"102\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Start time is missing\""));
        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"103\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"End time is missing\""));
        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"106\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Start date is missing\""));
        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"107\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"End date is missing\""));
        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"104\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Recurrence is mandatory\""));
        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"109\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Title is mandatory\""));
        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"111\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Type is missing\""));
        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"112\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Timezone is invalid/missing\""));
        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"114\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Associate Id is missing\""));
    }


    @Test(priority = 2)
    public void validate_CreateEvent_BFF_FrequencyErrorVerification() throws IOException {
        int count = 0;
        // String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("CREATE_EVENT_BFF_INVALID_REQUEST_BODY1")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("CREATE_EVENT_BFF_URL")).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().
                post(CommonUtils.getProperty("CREATE_EVENT_BFF_URL")).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"117\""));
        Assert.assertTrue(extractHeader.contains("\"frequency should be one of [daily / weekly / monthly]\""));

    }

    @Test(priority = 3)
    public void validate_CreateEvent_BFF_StartTimeErrorVerification() throws IOException {
        int count = 0;
        // String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("CREATE_EVENT_BFF_INVALID_REQUEST_BODY2")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("CREATE_EVENT_BFF_URL")).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().
                post(CommonUtils.getProperty("CREATE_EVENT_BFF_URL")).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"121\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Invalid time format. Please use HH:mm:SS\""));

    }

    @Test(priority = 4)
    public void validate_CreateEvent_BFF_EndtTimeErrorVerification() throws IOException {
        int count = 0;
        // String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("CREATE_EVENT_BFF_INVALID_REQUEST_BODY3")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("CREATE_EVENT_BFF_URL")).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().
                post(CommonUtils.getProperty("CREATE_EVENT_BFF_URL")).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"121\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Invalid time format. Please use HH:mm:SS\""));

    }

    @Test(priority = 5)
    public void validate_CreateEvent_BFF_StartDateErrorVerification() throws IOException {
        int count = 0;
        // String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("CREATE_EVENT_BFF_INVALID_REQUEST_BODY4")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("CREATE_EVENT_BFF_URL")).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().
                post(CommonUtils.getProperty("CREATE_EVENT_BFF_URL")).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"120\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Invalid date format. Please use yyyy-MM-dd\""));

    }

    @Test(priority = 6)
    public void validate_CreateEvent_BFF_EndDateErrorVerification() throws IOException {
        int count = 0;
        // String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("CREATE_EVENT_BFF_INVALID_REQUEST_BODY5")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("CREATE_EVENT_BFF_URL")).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().
                post(CommonUtils.getProperty("CREATE_EVENT_BFF_URL")).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"120\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Invalid date format. Please use yyyy-MM-dd\""));

    }

    @Test(priority = 7)
    public void validate_CreateEvent_BFF_TypeErrorVerification() throws IOException {
        int count = 0;
        // String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("CREATE_EVENT_BFF_INVALID_REQUEST_BODY6")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("CREATE_EVENT_BFF_URL")).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().
                post(CommonUtils.getProperty("CREATE_EVENT_BFF_URL")).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"119\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Type should be one of [Medical, Admin, Out of Office, Training, Lunch, Break, Other]\""));

    }

    @Test(priority = 8)
    public void validate_CreateEvent_BFF_AssociateIdErrorVerification() throws IOException {
        int count = 0;
        // String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("CREATE_EVENT_BFF_INVALID_REQUEST_BODY7")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("CREATE_EVENT_BFF_URL")).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().
                post(CommonUtils.getProperty("CREATE_EVENT_BFF_URL")).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"118\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Associate ID must contain only alphabets and numbers\""));

    }

    @Test(priority = 9)
    public void validate_CreateEvent_BFF_createdDateTimeErrorVerification() throws IOException {
        int count = 0;
        // String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("CREATE_EVENT_BFF_INVALID_REQUEST_BODY8")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("CREATE_EVENT_BFF_URL")).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().
                post(CommonUtils.getProperty("CREATE_EVENT_BFF_URL")).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"108\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Invalid time format. Please use YYYY-MM-DD HH:mm:SS\""));

    }

    @Test(priority = 10)
    public void validate_CreateEvent_BFF_UpdatedDateTimeErrorVerification() throws IOException {
        int count = 0;
        // String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("CREATE_EVENT_BFF_INVALID_REQUEST_BODY9")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("CREATE_EVENT_BFF_URL")).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().
                post(CommonUtils.getProperty("CREATE_EVENT_BFF_URL")).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"108\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"Invalid time format. Please use YYYY-MM-DD HH:mm:SS\""));

    }

    @Test(priority = 11)
    public void validate_CreateEvent_BFF_endTimeLesserErrorVerification() throws IOException {
        int count = 0;
        // String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("CREATE_EVENT_BFF_INVALID_REQUEST_BODY10")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("CREATE_EVENT_BFF_URL")).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().
                post(CommonUtils.getProperty("CREATE_EVENT_BFF_URL")).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"116\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"End time cannot be lesser than or equal to start time\""));

    }

    @Test(priority = 12)
    public void validate_CreateEvent_BFF_endDateLesserErrorVerification() throws IOException {
        int count = 0;
        // String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("CREATE_EVENT_BFF_INVALID_REQUEST_BODY11")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("CREATE_EVENT_BFF_URL")).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().
                post(CommonUtils.getProperty("CREATE_EVENT_BFF_URL")).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"115\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"End date cannot be lesser than start date\""));

    }

    @Test(priority = 13)
    public void validate_CreateEvent_BFF_EqualTimeErrorVerification() throws IOException {
        int count = 0;
        // String accessToken = validate_Auth_Request_Event();

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("CREATE_EVENT_BFF_INVALID_REQUEST_BODY12")), "utf-8");

        String extractHeader = given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("CREATE_EVENT_BFF_URL")).
                //  header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                        header(HEADER_AUTHORIZATION, "Basic bGVtcy11c2VyOnBhc3N3b3Jk").
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, "1").

                body(payload).
                when().
                post(CommonUtils.getProperty("CREATE_EVENT_BFF_URL")).
                then().
                log().all().
                //Assertions
                        statusCode(equalTo(400)).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).extract().response().asString();

        Assert.assertTrue(extractHeader.contains("\"errorCode\":\"116\""));
        Assert.assertTrue(extractHeader.contains("\"errorMessage\":\"End time cannot be lesser than or equal to start time\""));

    }

}
















