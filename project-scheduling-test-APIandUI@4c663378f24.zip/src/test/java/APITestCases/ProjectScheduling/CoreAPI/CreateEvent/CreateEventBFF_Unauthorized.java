package APITestCases.ProjectScheduling.CoreAPI.CreateEvent;

import com.lowes.ProjectScheduling.Utils.APIUtils.AuthRequest_Event;
import com.lowes.ProjectScheduling.Utils.CommonUtils.CommonUtils;
import org.apache.commons.io.FileUtils;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;

import static APITestCases.ProjectScheduling.CoreAPI.CreateEvent.CreateEvent_Success.eventId;
import static com.lowes.ProjectScheduling.Utils.CommonUtils.FileNameConstants.*;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class CreateEventBFF_Unauthorized extends AuthRequest_Event {

    @Test
    public void validate_Create_Event_BFF_Unauthorized() throws IOException {

        String accessToken = "null";

        String createEventPayload = FileUtils.readFileToString(new File(CommonUtils.getProperty("CREATE_EVENT_BFF_REQUEST_BODY")), "utf-8");
        given().relaxedHTTPSValidation().
                baseUri(CommonUtils.getProperty("CREATE_EVENT_BFF_URL")+eventId).
                header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
                header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
                header(HEADER_API_VERSION, 1).
                body(createEventPayload).
                when().
                post(CommonUtils.getProperty("CREATE_EVENT_BFF_URL")).
                then().
                log().all().
                statusCode(equalTo(401));

    }
}

