package APITestCases.ProjectScheduling.CoreAPI.GetSlots;
import com.lowes.ProjectScheduling.Utils.APIUtils.AuthRequest_Appointment;
import com.lowes.ProjectScheduling.Utils.CommonUtils.CommonUtils;
import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import static com.lowes.ProjectScheduling.Utils.CommonUtils.FileNameConstants.*;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
public class GetSlots_EmptyRequest extends AuthRequest_Appointment {


    @Test
    public void validate_GetSlots_Empty_Request() {

        String accessToken = validate_Auth_Request_Appointment();
        String payload = "";
        String extractheader = given().relaxedHTTPSValidation().
        baseUri(CommonUtils.getProperty("GET_SLOTS_URL")).
        header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
        header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
        body(payload).
        when().
        post(CommonUtils.getProperty("GET_SLOTS_URL")).
        then().
        log().all().
        statusCode(equalTo(400)).
        body("errorCode", Matchers.notNullValue()).extract().response().asString();
    }
}
