package APITestCases.ProjectScheduling.CoreAPI.GetSlots;

import com.lowes.ProjectScheduling.Utils.APIUtils.AuthRequest_Appointment;
import com.lowes.ProjectScheduling.Utils.CommonUtils.CommonUtils;
import org.apache.commons.io.FileUtils;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;

import static com.lowes.ProjectScheduling.Utils.CommonUtils.FileNameConstants.*;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class GetSlots_Unauthorized extends AuthRequest_Appointment {


    @Test
    public void validate_GetSlots_Unauthorized_Request() throws IOException {

        String accessToken = "null";

        String payload = FileUtils.readFileToString(new File(CommonUtils.getProperty("GET_SLOTS_REQUEST_BODY")), "utf-8");

      given().relaxedHTTPSValidation().
        baseUri(CommonUtils.getProperty("GET_SLOTS_URL")).
        header(HEADER_AUTHORIZATION, HEADER_BEARER + accessToken).
        header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON).
        body(payload).
        when().
        post(CommonUtils.getProperty("GET_SLOTS_URL")).
        then().
        log().all().
 //Assertions

        statusCode(equalTo(401)).
        header(HEADER_CONTENTTYPE, HEADER_APPLICATIONJSON_CHARSET);


    }


}

















