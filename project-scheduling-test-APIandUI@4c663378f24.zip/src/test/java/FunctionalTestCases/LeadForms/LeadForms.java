package FunctionalTestCases.LeadForms;

import com.lowes.ProjectScheduling.Pages.Base.BaseTest;
import com.lowes.ProjectScheduling.Utils.CommonUtils.DataProvidersLeadFormKitchen;
import com.lowes.ProjectScheduling.Utils.CommonUtils.DataProvidersLeadForms;
import org.testng.annotations.Test;

public class LeadForms extends BaseTest {


   @Test(priority = 1, dataProvider = "data-provider-leadforms", dataProviderClass = DataProvidersLeadForms.class)
    public void VerifyLeadFormForFencing(String pincode, String firstName, String lastName, String address, String phoneNo, String email, String description, String date) {

        //   ExcelDataMap.getValueForLeadForms();

        leadFormLandingPage.VerifyLandingPage(pincode,"fencing");
        leadFormLandingPage.VerifyContactInformationPage(firstName, lastName, address, phoneNo, email, description);
        leadFormScheduleConfirmationPage.VerifyBackButtonInScheduleConfirmationPage();
        leadFormLandingPage.VerifyNextButtonInContactInformationPage();
        leadFormScheduleConfirmationPage.VerifyScheduleConfirmationPage(firstName, lastName, phoneNo, email, description, date);
        leadFormConsultationConfirmationPage.VerifyConfirmationPage(firstName, lastName, date);
    }

   @Test(priority = 2, dataProvider = "data-provider-leadform-kitchen", dataProviderClass = DataProvidersLeadFormKitchen.class)
    public void VerifyLeadFormForKitchen(String pincode, String firstName, String lastName, String address,String City,String state,String Zipcode, String phoneNo, String email,  String timeline, String budget,String description,String date) {

        //   ExcelDataMap.getValueForLeadForms();

        leadFormLandingPage.VerifyLandingPage(pincode,"countertops");
        leadFormLandingPage.VerifyNewLeadFormContactInformationPage(firstName, lastName, address, City, state, Zipcode, phoneNo, email,timeline, budget,description);
        leadFormScheduleConfirmationPage.VerifyBackButtonInScheduleConfirmationPage();
        leadFormLandingPage.VerifyNextButtonInContactInformationPage();
        leadFormScheduleConfirmationPage.VerifyScheduleConfirmationPage(firstName, lastName, phoneNo, email, description, date);
        leadFormConsultationConfirmationPage.VerifyConfirmationPage(firstName, lastName, date);
    }
}
